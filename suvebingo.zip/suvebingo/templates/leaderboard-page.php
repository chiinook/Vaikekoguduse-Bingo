<?php defined( 'ABSPATH' ) || exit; ?>
<div id="suvebingo-leaderboard" class="suvebingo-wrap">
  <div class="sb-lb-header">
    <div class="sb-season-tag" id="sb-season-tag">Suvi 2026</div>
    <h1 class="sb-lb-title">Ühine <em>Edetabel</em></h1>
    <div class="sb-ornament">✦ ✦ ✦</div>
    <p class="sb-lb-subtitle">Väikekoguduste Suvebingo · EKB Liit</p>
  </div>

  <div class="sb-mode-toggle">
    <button class="sb-toggle-btn sb-ekb sb-active" id="sb-toggle-ekb" onclick="SuveBingoLB.setFilter('ekb')">
      🇪🇪 EKB <span class="sb-toggle-count" id="sb-count-ekb">0</span>
    </button>
    <div class="sb-toggle-divider"></div>
    <button class="sb-toggle-btn sb-oik" id="sb-toggle-obs" onclick="SuveBingoLB.setFilter('obs')">
      🔍 Vaatlusmäng <span class="sb-toggle-count" id="sb-count-obs">0</span>
    </button>
    <div class="sb-toggle-divider"></div>
    <button class="sb-toggle-btn sb-all" id="sb-toggle-all" onclick="SuveBingoLB.setFilter('all')" style="flex:0.6">Kõik</button>
  </div>

  <div class="sb-page-tabs">
    <button class="sb-page-tab sb-active" id="sb-tab-players" onclick="SuveBingoLB.setTab('players')">🏆 Top 10 mängijat</button>
    <button class="sb-page-tab" id="sb-tab-cards"   onclick="SuveBingoLB.setTab('cards')">📊 Top 10 kaardid</button>
    <button class="sb-page-tab" id="sb-tab-recent"  onclick="SuveBingoLB.setTab('recent')">🕐 Viimased külastused</button>
  </div>

  <div class="sb-stats-row">
    <div class="sb-stat-card"><strong id="sb-stat-participants">—</strong><span>osalejat</span></div>
    <div class="sb-stat-card"><strong id="sb-stat-visits">—</strong><span>külastust</span></div>
    <div class="sb-stat-card"><strong id="sb-stat-churches">—</strong><span>kogudust</span></div>
    <div class="sb-stat-card"><strong id="sb-stat-complete">—</strong><span>täis kaarti</span></div>
  </div>

  <div class="sb-tab-pane sb-active" id="sb-pane-players">
    <div class="sb-board-frame">
      <div class="sb-board-title">Top 10 mängijat <button onclick="SuveBingoLB.loadData()">↻ Uuenda</button></div>
      <div id="sb-leaderboard-body"><div class="sb-loading">Laen andmeid…</div></div>
    </div>
  </div>

  <div class="sb-tab-pane" id="sb-pane-cards">
    <div class="sb-cards-grid">
      <div class="sb-board-frame">
        <div class="sb-cards-section-title sb-ekb">🇪🇪 EKB — enimkülastatud kogudused</div>
        <div id="sb-ekb-cards-body"><div class="sb-loading">Laen…</div></div>
      </div>
      <div class="sb-board-frame">
        <div class="sb-cards-section-title sb-oik">🔍 Vaatlusmäng — sagedasemad tunnused</div>
        <div id="sb-oik-cards-body"><div class="sb-loading">Laen…</div></div>
      </div>
    </div>
  </div>

  <div class="sb-tab-pane" id="sb-pane-recent">
    <div class="sb-visits-frame">
      <div class="sb-board-title">Viimased külastused</div>
      <div id="sb-visits-body"><div class="sb-loading">Laen andmeid…</div></div>
    </div>
  </div>

  <div class="sb-last-updated" id="sb-last-updated"></div>
</div>
