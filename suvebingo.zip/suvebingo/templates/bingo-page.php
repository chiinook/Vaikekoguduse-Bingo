<?php defined( 'ABSPATH' ) || exit; ?>
<div id="suvebingo-app" class="suvebingo-wrap">

  <!-- ══ NO ACTIVE GAME ══ -->
  <div id="sb-screen-no-game" class="sb-screen" style="display:none">
    <div class="sb-register-box" style="text-align:center;padding:3rem 2rem">
      <div style="font-size:3rem;margin-bottom:1rem">⏳</div>
      <h2 style="font-family:'Playfair Display',serif;font-style:italic;color:#8b3a1a;margin-bottom:0.5rem">Mäng pole veel alanud</h2>
      <p style="color:#3a5c2e;font-style:italic">Suvebingo algab 1. juunil 2026. Tule tagasi siis!</p>
    </div>
  </div>

  <!-- ══ REGISTRATION ══ -->
  <div id="sb-screen-register" class="sb-screen sb-active">
    <div class="sb-register-box">
      <div class="sb-reg-emblem">⛪</div>
      <h1 class="sb-reg-title">Väikekoguduste<br><em>Suvebingo</em></h1>
      <p class="sb-reg-subtitle">Külasta. Julgusta. Teeni.</p>
      <div class="sb-date-badge" id="sb-date-badge">1. juuni – 31. august 2026</div>
      <div class="sb-ornament">✦ ✦ ✦</div>

      <div class="sb-mode-selector">
        <span class="sb-mode-label">Vali mängu tüüp</span>
        <div class="sb-mode-cards">
          <div class="sb-mode-card sb-ekb-card" id="sb-mode-ekb" onclick="SuveBingo.selectMode('ekb')">
            <span class="sb-mode-card-icon">🇪🇪</span>
            <span class="sb-mode-card-title">EKB</span>
            <span class="sb-mode-card-sub">EKB Liidu maakogudused + Vaatlusmäng</span>
          </div>
          <div class="sb-mode-card" id="sb-mode-obs" onclick="SuveBingo.selectMode('obs')">
            <span class="sb-mode-card-icon">🔍</span>
            <span class="sb-mode-card-title">Vaatlusmäng</span>
            <span class="sb-mode-card-sub">Kvalitatiivne — igale Eesti kogudusele</span>
          </div>
        </div>
      </div>

      <div class="sb-rules-box" id="sb-rules-box" style="display:none">
        <strong id="sb-rules-title">Mängureeglid</strong>
        <span id="sb-rules-text"></span>
      </div>

      <div class="sb-testimonials" id="sb-testimonials-block" style="display:none">
        <div class="sb-testimonials-label">Pastorite sõnad</div>
        <div id="sb-testimonials-list"></div>
      </div>

      <div class="sb-form-field">
        <label>Sinu nimi <span style="font-weight:400;opacity:0.6">(nähtav ainult administraatorile)</span></label>
        <input type="text" id="sb-reg-name" placeholder="Eesnimi Perekonnanimi" autocomplete="name">
      </div>
      <div class="sb-form-field">
        <label>Mängunimi / Hüüdnimi <span style="font-weight:400;opacity:0.6">(nähtav edetabelis)</span></label>
        <input type="text" id="sb-reg-display" placeholder="nt. Rändaja, Palverändar jne — jäta tühjaks esitähed+perekonnanimi">
      </div>
      <div class="sb-form-field">
        <label>E-posti aadress <span style="font-weight:400;opacity:0.6">(nähtav ainult administraatorile)</span></label>
        <input type="email" id="sb-reg-email" placeholder="nimi@kogudus.ee" autocomplete="email">
      </div>

      <div class="sb-ekb-fields" id="sb-ekb-fields">
        <div class="sb-form-field">
          <label>Sinu kodukogudus</label>
          <select id="sb-reg-home" onchange="SuveBingo.onHomeChurchChange()">
            <option value="">— Vali kogudus —</option>
          </select>
        </div>
        <div class="sb-partner-preview" id="sb-partner-preview" style="display:none">
          <span class="sb-partner-preview-label">🤝 Palvepartner <?php echo esc_html(date('Y')); ?></span>
          <div class="sb-partner-preview-name" id="sb-partner-preview-name"></div>
          <div class="sb-partner-preview-note">See kogudus lisatakse automaatselt sinu kaardile.</div>
        </div>
      </div>

      <div class="sb-form-field" id="sb-obs-home-field" style="display:none">
        <label>Sinu kodukogudus</label>
        <input type="text" id="sb-reg-home-obs" placeholder="Koguduse nimi">
      </div>

      <button class="sb-btn" onclick="SuveBingo.register()">Alusta mängu →</button>

      <div class="sb-resume-section">
        <button class="sb-btn-link" onclick="SuveBingo.showResume()">Jätka teisest seadmest →</button>
      </div>
      <div id="sb-resume-form" style="display:none;margin-top:1rem">
        <div class="sb-form-field">
          <label>Sinu e-posti aadress</label>
          <input type="email" id="sb-resume-email" placeholder="nimi@kogudus.ee">
        </div>
        <button class="sb-btn sb-btn-secondary" onclick="SuveBingo.sendResume()">Saada jätkamislink</button>
        <div id="sb-resume-status" style="font-size:0.85rem;margin-top:0.5rem;font-style:italic;color:#3a5c2e"></div>
      </div>
    </div>
  </div>

  <!-- ══ NEW SEASON PROMPT ══ -->
  <div id="sb-screen-new-season" class="sb-screen">
    <div class="sb-register-box" style="text-align:center">
      <div class="sb-reg-emblem">🎉</div>
      <h2 class="sb-reg-title">Uus <em>hooaeg</em> alanud!</h2>
      <p class="sb-reg-subtitle" id="sb-new-season-name"></p>
      <div class="sb-ornament">✦ ✦ ✦</div>
      <p style="margin-bottom:1.5rem;font-size:0.95rem;line-height:1.6">
        Tere tulemast tagasi! Sinu eelmise hooaja progress on salvestatud.<br>
        Uue hooaja alustamiseks genereerime sulle värske kaardi.
        <span id="sb-new-partner-note"></span>
      </p>
      <button class="sb-btn" onclick="SuveBingo.startNewSeason()">Alusta uut hooaega →</button>
      <br><br>
      <button class="sb-btn-link" onclick="SuveBingo.logout()">Logi välja</button>
    </div>
  </div>

  <!-- ══ MAIN APP ══ -->
  <div id="sb-screen-app" class="sb-screen">
    <div class="sb-app-header">
      <div class="sb-header-title">
        <span id="sb-header-subtitle">Suvebingo 2026</span>
        Väikekogudused
        <span class="sb-header-mode-badge" id="sb-header-mode-badge"></span>
      </div>
      <div class="sb-header-actions">
        <a href="<?php echo esc_url( home_url('/edetabel') ); ?>" class="sb-header-btn" target="_blank">Edetabel</a>
        <button class="sb-header-btn" onclick="SuveBingo.logout()">Vaheta</button>
      </div>
    </div>

    <div class="sb-score-strip">
      <div class="sb-score-item"><strong id="sb-score-visited">1</strong><span>külastust</span></div>
      <div class="sb-score-item"><strong id="sb-score-bingo">0</strong><span>bingot</span></div>
      <div class="sb-score-item"><strong id="sb-score-obs">0</strong><span>vaatlust</span></div>
      <div class="sb-score-item"><strong id="sb-score-left">24</strong><span>jäänud</span></div>
    </div>

    <div class="sb-app-body">

      <!-- How to visit guide -->
      <div class="sb-how-panel" id="sb-how-panel">
        <div class="sb-how-header" onclick="SuveBingo.toggleHow()">
          <span class="sb-rules-panel-title">📋 Kuidas maakogudust külastada</span>
          <span class="sb-rules-toggle" id="sb-how-toggle">▼</span>
        </div>
        <div class="sb-how-body" id="sb-how-body">
          <ol class="sb-how-list">
            <li>Vajuta kaardil koguduse ruudule ja ava koguduse leht <strong>kogudused.ee</strong>-s.</li>
            <li>Helista ette — anna teada oma külastusest ja küsi, kuidas saad teenistuses kaasa lüüa:
              <ul>
                <li>Too tervitused oma kodukogudusest</li>
                <li>Esita erilaudu</li>
                <li>Jaga oma tunnistust</li>
                <li>Loe kirjakohta</li>
                <li>Pea jutluse</li>
              </ul>
            </li>
            <li>Too kaasa väike mälestusese oma kodukogudusest — julgustav kingitus.</li>
            <li>Tutvusta end koguduse liikmetele ja selgita oma külastuse põhjust.</li>
            <li>Esita küsimusi ja märgi oma vaatluskaardile, milliseid koguduse tunnuseid sa märkasid.</li>
          </ol>
        </div>
      </div>

      <!-- Rules panel -->
      <div class="sb-rules-panel">
        <div class="sb-rules-panel-header" onclick="SuveBingo.toggleRules()">
          <span class="sb-rules-panel-title">Mängureeglid ja külastuse tingimused</span>
          <span class="sb-rules-toggle" id="sb-rules-toggle">▼</span>
        </div>
        <div class="sb-rules-panel-body" id="sb-rules-panel-body">
          <h4>Mis loeb külastusena?</h4>
          <ul>
            <li>Osaled koguduse jumalateenistusel või muul kogudusliku kogunemisel.</li>
            <li>Tood kaasa mingi panuse — rahaline annetus või aktiivne osalemine jumalateenistuses.</li>
          </ul>
          <h4>Kuidas mäng toimib?</h4>
          <ul>
            <li>Vajuta ruudule, et märkida külastus ja täita vaatluskaart.</li>
            <li>Bingo saavutatakse tervikliku reaga — horisontaalselt, vertikaalselt või diagonaalselt.</li>
            <li>Vaba ruut keskel tähistab sinu kodukogudust.</li>
          </ul>
          <div class="sb-partner-rule-highlight" id="sb-partner-rule" style="display:none">
            <span class="sb-partner-rule-icon">🤝</span>
            <div><strong>Palvepartner</strong><br>Sinu palvepartnerkogudus on kaardil kuldselt esile tõstetud. See on eriti oodatud külastus.</div>
          </div>
          <div class="sb-date-rule" id="sb-rules-dates">📅 Mäng kestab: 1. juuni – 31. august</div>
          <div class="sb-device-note">
            <strong>ℹ️ Seadmete vahel liikumine</strong>
            Sinu kaart on salvestatud serverisse. Teisest seadmest jätkamiseks kasuta registreerimisel olevat "Jätka teisest seadmest" linki — saadame sulle e-kirja koos jätkamislingiga.
          </div>
        </div>
      </div>

      <!-- Card toggle (EKB mode: show EKB or Vaatlusmäng card) -->
      <div class="sb-card-tabs" id="sb-card-tabs" style="display:none">
        <button class="sb-card-tab sb-active" id="sb-tab-ekb" onclick="SuveBingo.switchCard('ekb')">🇪🇪 EKB kaart</button>
        <button class="sb-card-tab" id="sb-tab-obs" onclick="SuveBingo.switchCard('obs')">🔍 Vaatluskaart</button>
      </div>

      <div class="sb-bingo-frame">
        <div class="sb-bingo-letters">
          <div class="sb-b-letter">B</div><div class="sb-b-letter">I</div>
          <div class="sb-b-letter">N</div><div class="sb-b-letter">G</div>
          <div class="sb-b-letter">O</div>
        </div>
        <div class="sb-bingo-grid" id="sb-bingo-grid"></div>
      </div>
      <div class="sb-region-legend" id="sb-region-legend" style="display:none"></div>
    </div>
  </div>

  <!-- ══ EKB VISIT MODAL ══ -->
  <div class="sb-modal-overlay" id="sb-modal-overlay">
    <div class="sb-modal">
      <span class="sb-modal-tag" id="sb-modal-tag">Ruut</span>
      <span class="sb-modal-sub-tag" id="sb-modal-sub-tag"></span>
      <h3 id="sb-modal-title">Kogudus</h3>
      <div id="sb-modal-church-link" style="display:none;margin-bottom:0.8rem">
        <a id="sb-church-link" href="#" target="_blank" class="sb-church-link">Vaata koguduse lehte kogudused.ee-s →</a>
      </div>
      <div class="sb-form-field" id="sb-modal-church-field" style="display:none">
        <label>Külastatud koguduse nimi</label>
        <input type="text" id="sb-modal-church" placeholder="Koguduse nimi">
      </div>
      <div class="sb-form-field">
        <label>Külastuse kuupäev</label>
        <input type="date" id="sb-modal-date">
      </div>
      <div class="sb-form-field">
        <label>Märkused <span style="opacity:0.5;font-weight:400">(vabatahtlik)</span></label>
        <textarea id="sb-modal-notes" id="sb-modal-notes"></textarea>
        <div class="sb-notes-prompt" id="sb-notes-prompt"></div>
      </div>
      <div class="sb-submit-status" id="sb-submit-status"></div>
      <div class="sb-modal-actions">
        <button class="sb-btn" onclick="SuveBingo.submitVisit()" id="sb-submit-btn">Salvesta külastus</button>
        <button class="sb-btn sb-ghost" onclick="SuveBingo.closeModal()">Tühista</button>
      </div>
    </div>
  </div>

  <!-- ══ VAATLUSMÄNG PANEL (slides in after EKB visit) ══ -->
  <div class="sb-obs-overlay" id="sb-obs-overlay">
    <div class="sb-obs-panel">
      <div class="sb-obs-header">
        <span class="sb-obs-title">🔍 Vaatluskaart</span>
        <span class="sb-obs-church-name" id="sb-obs-church-name"></span>
      </div>
      <p class="sb-obs-intro">Märgi kõik tunnused, mida selle koguduse puhul märkasid. Vaatlused aitavad EKB-l kogudusi paremini mõista ja toetada.</p>
      <div class="sb-obs-grid" id="sb-obs-grid"></div>
      <div class="sb-form-field" style="margin-top:1rem">
        <label>Üldised märkused <span style="font-weight:400;opacity:0.5">(vabatahtlik)</span></label>
        <textarea id="sb-obs-notes" placeholder="Kirjelda kogudust kolme sõnaga. Mis sind üllatas? Mida kogudus näib vajavat?"></textarea>
      </div>
      <div class="sb-obs-actions">
        <button class="sb-btn" onclick="SuveBingo.submitObservations()">Salvesta vaatlused</button>
        <button class="sb-btn sb-ghost" onclick="SuveBingo.closeObs()">Jäta vahele</button>
      </div>
      <p style="font-size:0.78rem;opacity:0.55;margin-top:0.8rem;font-style:italic">Vaatlused on konfidentsiaalsed — nähtavad ainult EKB Liidu administraatoritele.</p>
    </div>
  </div>

  <!-- ══ AWARD ══ -->
  <div class="sb-award-overlay" id="sb-award-overlay">
    <div class="sb-award-box">
      <span class="sb-award-emblem" id="sb-award-emblem">🏆</span>
      <div class="sb-award-tier" id="sb-award-tier">Saavutus</div>
      <div class="sb-award-title" id="sb-award-title">Palverändur</div>
      <div class="sb-award-desc" id="sb-award-desc"></div>
      <button class="sb-award-close" onclick="SuveBingo.closeAward()">Jätka →</button>
    </div>
  </div>

  <div class="sb-toast" id="sb-toast"></div>
</div>
