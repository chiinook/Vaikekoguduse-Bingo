/**
 * Suvebingo v2 — WordPress Plugin JavaScript
 */

/* ═══════════════════════════════════════════════════════════════
   CONFIG from WordPress (suvebingoConfig injected via wp_localize_script)
═══════════════════════════════════════════════════════════════ */
const SB_API   = (typeof suvebingoConfig !== 'undefined') ? suvebingoConfig.apiBase  : '/wp-json/suvebingo/v1';
const SB_NONCE = (typeof suvebingoConfig !== 'undefined') ? suvebingoConfig.nonce    : '';
const SB_GAME  = (typeof suvebingoConfig !== 'undefined') ? suvebingoConfig : {};

/* ═══════════════════════════════════════════════════════════════
   STATIC DATA
═══════════════════════════════════════════════════════════════ */

const SB_REGIONS = {
  'Harjumaa/Kesk': { color:'#8b3a1a', abbr:'HK' },
  'Edela-Eesti':   { color:'#3a5c2e', abbr:'EE' },
  'Lõuna-Eesti':   { color:'#b8890a', abbr:'LÕ' },
  'Virumaa':       { color:'#4a3520', abbr:'VI' },
  'Läänemaa':      { color:'#5c3a6e', abbr:'LÄ' },
  'Hiiumaa':       { color:'#1a5c5c', abbr:'HI' },
  'Saaremaa':      { color:'#6e4a1a', abbr:'SA' },
  'Tallinn':       { color:'#2a2060', abbr:'TL' },
  'Muu':           { color:'#555555', abbr:'—'  },
};

// Church URL map — populated from server on init
let SB_CHURCH_URLS = {};
// Full church list — populated from server on init
let SB_ALL_CHURCHES = [];
// Prayer partners for current game — populated from server
let SB_PRAYER_PARTNERS = {};

// EKB pool (static, matches database seed)
const SB_EKB_POOL = [
  {name:'Kehra Kogudus',                        region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Keila Baptisti Kogudus',               region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Koeru Vabakogudus',                    region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Kohila Baptistikogudus',               region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Laitse Kogudus',                       region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Loksa Baptisti Kogudus',               region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Märjamaa Vabakogudus',                 region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Paide Baptistikogudus',                region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Rapla Vabakogudus',                    region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Valkla Baptistikogudus',               region:'Harjumaa/Kesk',icon:'⛪'},
  {name:'Järvekandi Uue Alguse Kogudus',        region:'Harjumaa/Kesk',icon:'🌱'},
  {name:'3D Kogudus',                           region:'Edela-Eesti',  icon:'⛪'},
  {name:'EK Suigu Kogudus',                     region:'Edela-Eesti',  icon:'⛪'},
  {name:'Kilingi-Nõmme Vabakogudus',            region:'Edela-Eesti',  icon:'⛪'},
  {name:'Suure-Jaani Baptisti Kogudus',         region:'Edela-Eesti',  icon:'⛪'},
  {name:'Antsla EKB Kogudus',                   region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Elva Baptistikogudus',                 region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Jõgeva Baptistikogudus',               region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Mooste Baptistikogudus',               region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Otepää EV "Palverändur"',              region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Puka Vabakogudus',                     region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Sadala Baptisti Kogudus',              region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Selise Baptistikogudus',               region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Tõrva Immaanueli Kogudus',             region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Valga Betaania Baptistikogudus',       region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Valga Peeteli EKB Kogudus',            region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Viljandi Baptistikogudus',             region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Võru Baptisti Kogudus',                region:'Lõuna-Eesti',  icon:'⛪'},
  {name:'Avispea Vabakogudus',                  region:'Virumaa',      icon:'⛪'},
  {name:'Kohtla-Järve Saaroni Baptisti Kogudus',region:'Virumaa',      icon:'⛪'},
  {name:'Mustvee Betaania Kogudus',             region:'Virumaa',      icon:'⛪'},
  {name:'Rakke Kogudus',                        region:'Virumaa',      icon:'⛪'},
  {name:'Tapa Elava Usu Kogudus',               region:'Virumaa',      icon:'⛪'},
  {name:'Haapsalu Baptistikogudus',             region:'Läänemaa',     icon:'⛪'},
  {name:'Lihula Baptistikogudus',               region:'Läänemaa',     icon:'⛪'},
  {name:'Mäevalla palvela',                     region:'Läänemaa',     icon:'🕯️'},
  {name:'Palivere EKV Kogudus',                 region:'Läänemaa',     icon:'⛪'},
  {name:'Ridala Baptisti Kogudus',              region:'Läänemaa',     icon:'⛪'},
  {name:'Sutlepa Baptisti Kogudus',             region:'Läänemaa',     icon:'⛪'},
  {name:'Vormsi Rälby Baptisti Kogudus',        region:'Läänemaa',     icon:'🏝️'},
  {name:'Emmaste-Nurste Kogudus',               region:'Hiiumaa',      icon:'🏝️'},
  {name:'Harju EKB Kogudus',                    region:'Hiiumaa',      icon:'🏝️'},
  {name:'Hiiumaa Kristlik Misjonikogudus',      region:'Hiiumaa',      icon:'🏝️'},
  {name:'Hilleste Kristlik Kogudus',            region:'Hiiumaa',      icon:'🏝️'},
  {name:'Jausa Kogudus',                        region:'Hiiumaa',      icon:'🏝️'},
  {name:'Käina EKB Kogudus',                    region:'Hiiumaa',      icon:'🏝️'},
  {name:'Kärdla Baptistikogudus',               region:'Hiiumaa',      icon:'🏝️'},
  {name:'Lauka palvela',                        region:'Hiiumaa',      icon:'🕯️'},
  {name:'Luguse Kogudus',                       region:'Hiiumaa',      icon:'🏝️'},
  {name:'Palade Priikogudus',                   region:'Hiiumaa',      icon:'🏝️'},
  {name:'Ühtri palvela',                        region:'Hiiumaa',      icon:'🕯️'},
  {name:'Eikla Priikogudus',                    region:'Saaremaa',     icon:'🏝️'},
  {name:'Kuressaare Siioni Kogudus',            region:'Saaremaa',     icon:'🏝️'},
  {name:'Leisi Baptisti Kogudus',               region:'Saaremaa',     icon:'🏝️'},
  {name:'Meiuste EKB Kogudus',                  region:'Saaremaa',     icon:'🏝️'},
  {name:'Valjala Rahu Vabakogudus',             region:'Saaremaa',     icon:'🏝️'},
  {name:'K13',                                  region:'Tallinn',      icon:'🌱'},
  {name:'Ühisosa',                              region:'Tallinn',      icon:'🌱'},
  {name:'Tallinna Korea Kogudus',               region:'Tallinn',      icon:'🌱'},
];

const SB_OIK_SQUARES = [
  {icon:'📖', label:'Kogudus ilma pühapäevakoolita'},
  {icon:'🌙', label:'Kogudus, mis koguneb muul ajal kui pühapäeva hommik'},
  {icon:'👥', label:'Alla 20 liikmega kogudus'},
  {icon:'🏠', label:'Kodukogudus (koguneb erakodus)'},
  {icon:'🌾', label:'Maapiirkonna kogudus'},
  {icon:'🙏', label:'Ilmikust juhiga kogudus'},
  {icon:'🌐', label:'Vähemuskeelne kogudus'},
  {icon:'🔑', label:'Omal hoonel puuduv kogudus'},
  {icon:'👴', label:'60+ keskmise vanusega kogudus'},
  {icon:'🌱', label:'Alla 5-aastane kogudus'},
  {icon:'✝️', label:'Erineva traditsiooniga kogudus'},
  {icon:'🚗', label:'50+ km kaugusel asuv kogudus'},
  {icon:'🎵', label:'Ainult a cappella jumalateenistusega kogudus'},
  {icon:'👶', label:'Lasteministeeriumita kogudus'},
  {icon:'🌍', label:'Immigrantide kogudus'},
  {icon:'🤝', label:'Kogudus, mis tegutseb koos teise kogudusega'},
  {icon:'🗺️', label:'Teises maakonnas asuv kogudus'},
  {icon:'⛪', label:'Mitut kogudust teeniv juht'},
  {icon:'🛠️', label:'Praktiliselt teenitud kogudus'},
  {icon:'👫', label:'Ühe põlvkonna kogudus'},
  {icon:'🍞', label:'Armulauaga jumalateenistus'},
  {icon:'🌆', label:'Õhtune jumalateenistus'},
  {icon:'🏔️', label:'Raskesti ligipääsetav kogudus'},
  {icon:'📅', label:'Harvem kui kord nädalas kogunev kogudus'},
];

const SB_NOTES_PROMPTS = [
  'Milline on koguduse üldine meeleolu?',
  'Mis sind üllatas?',
  'Mida kogudus näib vajavat?',
  'Kirjelda jumalateenistust kolme sõnaga.',
  'Kellega kohtusid ja mida said teada?',
];

const SB_FREE_CELL   = {name:'VABA',label:'VABA',region:'',icon:'⛪',free:true};
const SB_COL_LETTERS = ['B','I','N','G','O'];
const SB_BINGO_LINES = [
  [0,1,2,3,4],[5,6,7,8,9],[10,11,12,13,14],[15,16,17,18,19],[20,21,22,23,24],
  [0,5,10,15,20],[1,6,11,16,21],[2,7,12,17,22],[3,8,13,18,23],[4,9,14,19,24],
  [0,6,12,18,24],[4,8,12,16,20],
];
const SB_AWARDS = [
  {visits:1,  bingos:0,emblem:'👣',tier:'Esimene samm',    title:'Rändurite õnnistus',   desc:'Sa oled alustanud teekonda!'},
  {visits:5,  bingos:0,emblem:'✉️',tier:'Külastaja',       title:'Koguduste külastaja',  desc:'Viis kogudust — sa kannad julgustust laiali!'},
  {visits:0,  bingos:1,emblem:'⭐',tier:'Esimene bingo',   title:'Palverändur',          desc:'Esimene bingoliin täis!'},
  {visits:10, bingos:0,emblem:'🤝',tier:'Koguduste sõber', title:'Koguduste sõber',      desc:'Kümme kogudust — sa oled eriline kingitus neile!'},
  {visits:0,  bingos:3,emblem:'🌟',tier:'Suveläkitaja',    title:'Suveläkitaja',         desc:'Kolm bingoliini — sa elad seda missiooni!'},
  {visits:24, bingos:0,emblem:'👑',tier:'Täielik kaart',   title:'Väikekoguduste bajtar',desc:'Kõik 24 ruutu täidetud!'},
];
const SB_RULES = {
  ekb: 'EKB kaardil on 24 juhuslikult valitud EKB Liidu maakogudust. Iga külastus avab automaatselt ka Vaatluskaardi, kus saad märkida koguduse tunnuseid. Külastus peab sisaldama jumalateenistust ja panust.',
  obs: 'Vaatluskaardil märgid koguduse tunnuseid, mida sa ise avastasid. Mäng on avatud kõikidele Eesti koguduse külastustele — mitte ainult EKB Liidu liikmetele.',
};

/* ═══════════════════════════════════════════════════════════════
   UTILITIES
═══════════════════════════════════════════════════════════════ */
function sbToday() {
  const d=new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function sbEsc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function sbEl(id){return document.getElementById(id);}
function sbRandPrompt(){return SB_NOTES_PROMPTS[Math.floor(Math.random()*SB_NOTES_PROMPTS.length)];}

/* ═══════════════════════════════════════════════════════════════
   GAME NAMESPACE
═══════════════════════════════════════════════════════════════ */
const SuveBingo = (function(){

  let participant = null;
  let card        = [];
  let obsCard     = [...SB_OIK_SQUARES];
  let marked      = new Set();
  let obsMarked   = new Set();
  let bingoLines  = new Set();
  let totalBingos = 0;
  let awardQueue  = [];
  let awardsGiven = new Set();
  let activeCell  = null;
  let selectedMode= null;
  let activeCardView = 'ekb'; // 'ekb' or 'obs'
  let pendingObsChurch = null; // church name waiting for obs submission

  // ── API ─────────────────────────────────────────────────────
  async function api(endpoint, method='GET', body=null){
    const opts={method,headers:{'Content-Type':'application/json','X-WP-Nonce':SB_NONCE}};
    if(participant&&participant.token) opts.headers['Authorization']='Bearer '+participant.token;
    if(body) opts.body=JSON.stringify(body);
    const res=await fetch(SB_API+endpoint,opts);
    if(!res.ok){const e=await res.json().catch(()=>({}));throw new Error(e.message||'Viga '+res.status);}
    return res.json();
  }

  // ── Init ────────────────────────────────────────────────────
  async function init(){
    if(!sbEl('suvebingo-app')) return;

    // Check game active
    if(SB_GAME.gameActive===false){
      showScreen('no-game'); return;
    }

    // Load church data from server
    try {
      const churches = await api('/churches');
      SB_ALL_CHURCHES = churches.map(c=>c.name).sort();
      churches.forEach(c=>{ if(c.ekb_url) SB_CHURCH_URLS[c.name]=c.ekb_url; });
    } catch(e){}

    populateDropdown();
    loadTestimonials();
    updateDateBadge();

    // Check for resume token in URL
    const params=new URLSearchParams(window.location.search);
    const token=params.get('suvebingo_resume');
    if(token&&/^[0-9a-f]{64}$/.test(token)){
      await resumeWithToken(token);
      window.history.replaceState({},'',window.location.pathname);
      return;
    }
    // Check localStorage
    const saved=localStorage.getItem('sb_session');
    if(saved){try{const s=JSON.parse(saved);if(s.token)await resumeWithToken(s.token);}catch(e){localStorage.removeItem('sb_session');}}
    else showScreen('register');

    sbEl('sb-modal-overlay').addEventListener('click',e=>{if(e.target===sbEl('sb-modal-overlay'))closeModal();});
  }

  function updateDateBadge(){
    const badge=sbEl('sb-date-badge');
    if(badge&&SB_GAME.gameStart&&SB_GAME.gameEnd){
      const fmt=d=>new Date(d).toLocaleDateString('et-EE',{day:'numeric',month:'long'});
      badge.textContent=fmt(SB_GAME.gameStart)+' – '+fmt(SB_GAME.gameEnd)+' '+SB_GAME.gameYear;
    }
    const ruleDates=sbEl('sb-rules-dates');
    if(ruleDates&&SB_GAME.gameStart) ruleDates.textContent='📅 Mäng kestab: '+SB_GAME.gameStart+' – '+SB_GAME.gameEnd;
  }

  async function resumeWithToken(token){
    try{
      participant={token};
      const data=await api('/card');
      // Check if this participant is from a different game season
      if(data.game_id&&SB_GAME.gameId&&data.game_id!==SB_GAME.gameId){
        participant={token,name:data.name,display_name:data.display_name,email:data.email,
          home_church:data.home_church,mode:data.mode,partner:data.partner,game_id:data.game_id};
        // Show new season prompt
        const nsn=sbEl('sb-new-season-name');
        if(nsn) nsn.textContent=SB_GAME.gameName||'';
        showScreen('new-season');
        return;
      }
      participant={token,name:data.name,display_name:data.display_name,email:data.email,
        home_church:data.home_church,mode:data.mode,partner:data.partner,game_id:data.game_id};
      localStorage.setItem('sb_session',JSON.stringify({token}));
      card       =JSON.parse(data.ekb_card_json||'[]');
      marked     =new Set(JSON.parse(data.ekb_marked||'[12]'));
      obsMarked  =new Set(JSON.parse(data.obs_marked||'[]'));
      totalBingos=data.ekb_bingos||0;
      showScreen('app'); applyModeUI(); renderGrid(); renderLegend(); updateScore();
      reapplyBingoStyles();
    }catch(e){localStorage.removeItem('sb_session');participant=null;showScreen('register');}
  }

  async function loadTestimonials(){
    try{
      const data=await api('/testimonials');
      if(!data.length) return;
      sbEl('sb-testimonials-block').style.display='block';
      sbEl('sb-testimonials-list').innerHTML=data.map(t=>
        `<div class="sb-testimonial">${sbEsc(t.quote)}<span class="sb-testimonial-author">— ${sbEsc(t.author)}</span></div>`
      ).join('');
    }catch(e){}
  }

  // ── Registration ────────────────────────────────────────────
  function populateDropdown(){
    const sel=sbEl('sb-reg-home');
    if(!sel) return;
    // Remove existing options except first
    while(sel.options.length>1) sel.remove(1);
    SB_ALL_CHURCHES.forEach(name=>{
      const o=document.createElement('option');
      o.value=name;o.textContent=name;sel.appendChild(o);
    });
  }

  function selectMode(mode){
    selectedMode=mode;
    sbEl('sb-mode-ekb').classList.toggle('sb-selected',mode==='ekb');
    sbEl('sb-mode-obs').classList.toggle('sb-selected',mode==='obs');
    const rb=sbEl('sb-rules-box');rb.style.display='block';
    sbEl('sb-rules-title').textContent=mode==='ekb'?'EKB mängureeglid':'Vaatlusmängu reeglid';
    sbEl('sb-rules-text').textContent=SB_RULES[mode];
    sbEl('sb-ekb-fields').classList.toggle('sb-visible',mode==='ekb');
    sbEl('sb-obs-home-field').style.display=mode==='obs'?'block':'none';
    if(mode!=='ekb') sbEl('sb-partner-preview').style.display='none';
  }

  function onHomeChurchChange(){
    const home=sbEl('sb-reg-home').value;
    const preview=sbEl('sb-partner-preview');
    if(!home){preview.style.display='none';return;}
    // Look up partner via prayer partners (loaded from server after registration, pre-filled from JS data)
    // We'll update this after getting game data
    preview.style.display='none'; // Will be shown after partners load
    // For now show placeholder
    sbEl('sb-partner-preview-name').textContent='Laen palvepartnerit…';
    preview.style.display='block';
    // Fetch partner for this church in current game
    api('/churches').then(churches=>{
      // Partners are loaded per-game from server at card build time
      preview.style.display='none';
    }).catch(()=>preview.style.display='none');
  }

  async function register(){
    if(!selectedMode){showToast('Palun vali mängu tüüp.');return;}
    const name        =sbEl('sb-reg-name').value.trim();
    const display_name=sbEl('sb-reg-display').value.trim();
    const email       =sbEl('sb-reg-email').value.trim();
    if(!name||!email){showToast('Palun täida nimi ja e-post.');return;}
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){showToast('Kehtetu e-post.');return;}

    let home_church='',partner='';
    if(selectedMode==='ekb'){
      home_church=sbEl('sb-reg-home').value;
      if(!home_church){showToast('Palun vali kodukogudus.');return;}
      // Fetch partner from server for this game
      try{
        const prow=await fetch(SB_API+'/churches').then(r=>r.json()).catch(()=>[]);
        // Partner comes from game-specific partners table — we pass home_church and server resolves it
      }catch(e){}
    }else{
      home_church=sbEl('sb-reg-home-obs').value.trim();
    }

    const builtCard=buildCard(selectedMode,home_church,'');
    const btn=document.querySelector('#sb-screen-register .sb-btn');
    try{
      if(btn){btn.disabled=true;btn.textContent='Registreerin…';}
      const data=await api('/register','POST',{
        name,display_name,email,home_church,mode:selectedMode,partner,
        card_json:JSON.stringify(builtCard),
      });
      participant={name,display_name:display_name||name.split(' ')[0],email,home_church,
        mode:selectedMode,partner:data.partner||'',token:data.token,game_id:SB_GAME.gameId};
      localStorage.setItem('sb_session',JSON.stringify({token:data.token}));
      card=builtCard; marked=new Set([12]); obsMarked=new Set();
      bingoLines=new Set(); totalBingos=0; awardsGiven=new Set(); awardQueue=[];
      showScreen('app'); applyModeUI(); renderGrid(); renderLegend(); updateScore();
    }catch(e){
      showToast('Viga: '+e.message);
      if(btn){btn.disabled=false;btn.textContent='Alusta mängu →';}
    }
  }

  async function startNewSeason(){
    const builtCard=buildCard(participant.mode,participant.home_church,'');
    try{
      const data=await api('/new-season','POST',{card_json:JSON.stringify(builtCard)});
      if(data.already_registered){showToast('Sa oled juba selle hooajaga liitunud.');return;}
      participant={...participant,token:data.token,partner:data.partner||'',game_id:SB_GAME.gameId};
      localStorage.setItem('sb_session',JSON.stringify({token:data.token}));
      card=builtCard; marked=new Set([12]); obsMarked=new Set();
      bingoLines=new Set(); totalBingos=0; awardsGiven=new Set(); awardQueue=[];
      showScreen('app'); applyModeUI(); renderGrid(); renderLegend(); updateScore();
    }catch(e){showToast('Viga: '+e.message);}
  }

  function logout(){
    if(!confirm('Logi välja?')) return;
    localStorage.removeItem('sb_session');
    participant=null;selectedMode=null;card=[];marked=new Set();obsMarked=new Set();
    bingoLines=new Set();totalBingos=0;
    ['sb-mode-ekb','sb-mode-obs'].forEach(id=>sbEl(id)&&sbEl(id).classList.remove('sb-selected'));
    const rb=sbEl('sb-rules-box');if(rb) rb.style.display='none';
    const ef=sbEl('sb-ekb-fields');if(ef) ef.classList.remove('sb-visible');
    const of=sbEl('sb-obs-home-field');if(of) of.style.display='none';
    showScreen('register');
  }

  function showResume(){
    const rf=sbEl('sb-resume-form');
    if(rf) rf.style.display=rf.style.display==='none'?'block':'none';
  }

  async function sendResume(){
    const email=sbEl('sb-resume-email').value.trim();
    if(!email){showToast('Palun sisesta e-post.');return;}
    const status=sbEl('sb-resume-status');
    status.textContent='Saadan…';
    try{await api('/resume','POST',{email});status.textContent='Link saadetud! Kontrolli e-posti.';}
    catch(e){status.textContent='Viga saatmisel.';}
  }

  // ── Card build ───────────────────────────────────────────────
  function buildCard(mode,home_church,partner){
    const result=[];
    if(mode==='ekb'){
      const pool=SB_EKB_POOL.filter(c=>c.name!==home_church);
      const partnerObj=partner?(SB_EKB_POOL.find(c=>c.name===partner)||{name:partner,region:'Muu',icon:'🤝'}):null;
      const rPool=partnerObj?pool.filter(c=>c.name!==partner):pool;
      const shuffled=[...rPool].sort(()=>Math.random()-0.5);
      const rCount=partnerObj?23:24;
      let slots=partnerObj?[...shuffled.slice(0,rCount),{...partnerObj,isPartner:true}]:shuffled.slice(0,rCount);
      slots=slots.sort(()=>Math.random()-0.5);
      let si=0;
      for(let i=0;i<25;i++){
        if(i===12) result.push({...SB_FREE_CELL,index:i});
        else{result.push({...slots[si],index:i});si++;}
      }
    }else{
      const shuffled=[...SB_OIK_SQUARES].sort(()=>Math.random()-0.5);
      let si=0;
      for(let i=0;i<25;i++){
        if(i===12) result.push({...SB_FREE_CELL,index:i});
        else{result.push({...shuffled[si],index:i});si++;}
      }
    }
    return result;
  }

  // ── Screen / UI ──────────────────────────────────────────────
  function showScreen(name){
    document.querySelectorAll('.sb-screen').forEach(s=>s.classList.remove('sb-active'));
    const el=sbEl('sb-screen-'+name);
    if(el) el.classList.add('sb-active');
  }

  function applyModeUI(){
    const mode=participant?participant.mode:'ekb';
    const badge=sbEl('sb-header-mode-badge');
    if(badge){badge.textContent=mode==='ekb'?'EKB':'Vaatlusmäng';badge.className='sb-header-mode-badge '+(mode==='ekb'?'ekb':'oik');}
    const sub=sbEl('sb-header-subtitle');
    if(sub) sub.textContent=(SB_GAME.gameName||'Suvebingo '+(SB_GAME.gameYear||2026));
    const pr=sbEl('sb-partner-rule');
    if(pr) pr.style.display=(mode==='ekb'&&participant&&participant.partner)?'flex':'none';
    // Show card tabs only in EKB mode
    const tabs=sbEl('sb-card-tabs');
    if(tabs) tabs.style.display=mode==='ekb'?'flex':'none';
  }

  function switchCard(view){
    activeCardView=view;
    sbEl('sb-tab-ekb')&&sbEl('sb-tab-ekb').classList.toggle('sb-active',view==='ekb');
    sbEl('sb-tab-obs')&&sbEl('sb-tab-obs').classList.toggle('sb-active',view==='obs');
    renderGrid();
  }

  function toggleRules(){
    const body=sbEl('sb-rules-panel-body');
    const toggle=sbEl('sb-rules-toggle');
    const header=document.querySelector('.sb-rules-panel-header');
    if(!body) return;
    const open=body.classList.toggle('sb-open');
    if(toggle) toggle.classList.toggle('sb-open',open);
    if(header) header.classList.toggle('sb-open',open);
  }

  function toggleHow(){
    const body=sbEl('sb-how-body');
    const toggle=sbEl('sb-how-toggle');
    if(!body) return;
    const open=body.classList.toggle('sb-open');
    if(toggle) toggle.classList.toggle('sb-open',open);
  }

  // ── Grid render ──────────────────────────────────────────────
  function renderGrid(){
    const mode=participant?participant.mode:'ekb';
    const grid=sbEl('sb-bingo-grid');
    if(!grid) return;
    grid.innerHTML='';

    const isObsView=(mode==='ekb'&&activeCardView==='obs');
    const displayCard=isObsView?SB_OIK_SQUARES.map((sq,i)=>({...sq,index:i})):card;
    const displayMarked=isObsView?obsMarked:marked;

    displayCard.forEach((sq,i)=>{
      const colLetter=SB_COL_LETTERS[i%5];
      const rowNum=Math.floor(i/5)+1;
      const isPartner=!!sq.isPartner;
      const isMarked=displayMarked.has(i)&&!sq.free;
      const cell=document.createElement('div');
      cell.className='sb-cell'+(sq.free?' sb-free':'')+(isMarked?' sb-marked':'')+(isPartner&&!isMarked?' sb-partner':'');

      if(!isObsView&&mode==='ekb'&&!sq.free&&sq.region&&SB_REGIONS[sq.region]&&!isPartner){
        cell.style.borderTopColor=SB_REGIONS[sq.region].color;
        cell.style.borderTopWidth='3px';
      }

      let inner=`<span class="sb-cell-check">✓</span>`;
      if(sq.free){
        inner+=`<span class="sb-cell-icon">${sq.icon}</span><span class="sb-cell-name">VABA</span>`;
      }else if(!isObsView&&mode==='ekb'){
        if(isPartner) inner+=`<span class="sb-partner-label">🤝 Palvepartner</span>`;
        inner+=`<span class="sb-cell-icon">${sq.icon}</span><span class="sb-cell-name">${sbEsc(sq.name)}</span>`;
        if(sq.region&&SB_REGIONS[sq.region]) inner+=`<span class="sb-cell-sub">${SB_REGIONS[sq.region].abbr}</span>`;
      }else{
        inner+=`<span class="sb-cell-icon">${sq.icon}</span><span class="sb-cell-name">${sbEsc(sq.label||sq.name)}</span>`;
      }
      cell.innerHTML=inner;
      if(!sq.free) cell.onclick=()=>openModal(i,sq,colLetter+rowNum,isObsView);
      grid.appendChild(cell);
    });
    if(!isObsView) reapplyBingoStyles();
  }

  function renderLegend(){
    const legend=sbEl('sb-region-legend');
    if(!legend) return;
    if(!participant||participant.mode!=='ekb'||activeCardView==='obs'){legend.style.display='none';return;}
    const used=new Set(card.filter(c=>!c.free&&!c.isPartner).map(c=>c.region));
    const hasPartner=card.some(c=>c.isPartner);
    let html=[...used].filter(r=>SB_REGIONS[r]).map(r=>
      `<div class="sb-legend-item"><div class="sb-legend-dot" style="background:${SB_REGIONS[r].color}"></div><span>${r}</span></div>`
    ).join('');
    if(hasPartner) html+=`<div class="sb-legend-partner"><div class="sb-legend-partner-dot"></div><span>Palvepartner</span></div>`;
    legend.style.display='flex';legend.innerHTML=html;
  }

  function reapplyBingoStyles(){
    const cells=document.querySelectorAll('.sb-cell');
    bingoLines.forEach(li=>SB_BINGO_LINES[li].forEach(ci=>{if(cells[ci])cells[ci].classList.add('sb-bingo-line');}));
  }

  // ── Modal ────────────────────────────────────────────────────
  function openModal(index,sq,label,isObsMode=false){
    if(isObsMode){
      if(obsMarked.has(index)){showToast('See on juba märgitud.');return;}
    }else{
      if(marked.has(index)){showToast('See on juba märgitud.');return;}
    }
    activeCell={index,sq,label,isObsMode};
    const mode=participant?participant.mode:'ekb';
    const isPartner=!!sq.isPartner;
    const tag=sbEl('sb-modal-tag');
    const subTag=sbEl('sb-modal-sub-tag');
    const title=sbEl('sb-modal-title');
    const cField=sbEl('sb-modal-church-field');
    const cInput=sbEl('sb-modal-church');
    const churchLinkDiv=sbEl('sb-modal-church-link');
    const churchLink=sbEl('sb-church-link');
    const notesPrompt=sbEl('sb-notes-prompt');

    if(isObsMode){
      tag.textContent='🔍 Vaatlusmäng';tag.className='sb-modal-tag sb-partner';
      subTag.textContent='';title.textContent=sq.label;
      cField.style.display='block';cInput.value='';
      churchLinkDiv.style.display='none';
    }else if(mode==='ekb'){
      tag.textContent=isPartner?'🤝 Palvepartner':label;
      tag.className='sb-modal-tag sb-ekb'+(isPartner?' sb-partner':'');
      subTag.textContent=sq.region||'';title.textContent=sq.name;
      cField.style.display='none';cInput.value=sq.name;
      // Show kogudused.ee link
      const url=SB_CHURCH_URLS[sq.name];
      if(url&&churchLink&&churchLinkDiv){
        churchLink.href=url;churchLinkDiv.style.display='block';
      }else if(churchLinkDiv){churchLinkDiv.style.display='none';}
    }else{
      tag.textContent=label;tag.className='sb-modal-tag sb-oik';
      subTag.textContent='';title.textContent=sq.label;
      cField.style.display='block';cInput.value='';
      if(churchLinkDiv) churchLinkDiv.style.display='none';
    }

    sbEl('sb-modal-notes').value='';
    sbEl('sb-modal-notes').placeholder=sbRandPrompt();
    if(notesPrompt) notesPrompt.textContent='';
    sbEl('sb-modal-date').value=sbToday();
    sbEl('sb-submit-status').textContent='';
    sbEl('sb-submit-btn').disabled=false;
    sbEl('sb-modal-overlay').classList.add('sb-open');
  }

  function closeModal(){sbEl('sb-modal-overlay').classList.remove('sb-open');activeCell=null;}

  // ── Submit EKB visit ─────────────────────────────────────────
  async function submitVisit(){
    if(!activeCell||!participant) return;
    const mode=participant.mode;
    const dateVal=sbEl('sb-modal-date').value;
    const notes=sbEl('sb-modal-notes').value.trim();
    const churchVal=sbEl('sb-modal-church').value.trim();

    if(!dateVal){showToast('Palun vali kuupäev.');return;}

    // Obs-mode-only square
    if(activeCell.isObsMode){
      if(!churchVal){showToast('Palun sisesta koguduse nimi.');return;}
      sbEl('sb-submit-btn').disabled=true;
      sbEl('sb-submit-status').textContent='Saadan…';
      try{
        await api('/observe','POST',{
          church_name:churchVal,square_num:activeCell.label,
          square_label:activeCell.sq.label,visit_date:dateVal,notes:notes.substring(0,2000),
        });
        obsMarked.add(activeCell.index);
        const cells=document.querySelectorAll('.sb-cell');
        if(cells[activeCell.index]) cells[activeCell.index].classList.add('sb-marked');
        await api('/card','PUT',{obs_marked:JSON.stringify([...obsMarked])});
        updateScore();sbEl('sb-submit-status').textContent='✓ Salvestatud!';
        setTimeout(()=>{closeModal();showToast('Vaatlus salvestatud ✓');},600);
      }catch(e){
        sbEl('sb-submit-status').textContent='Viga: '+e.message;
        sbEl('sb-submit-btn').disabled=false;
      }
      return;
    }

    const churchName=mode==='ekb'?activeCell.sq.name:churchVal;
    if(mode==='obs'&&!churchVal){showToast('Palun sisesta koguduse nimi.');return;}

    sbEl('sb-submit-btn').disabled=true;
    sbEl('sb-submit-status').textContent='Saadan…';
    try{
      await api('/visit','POST',{
        church_name:churchName,square_num:activeCell.label,
        visit_date:dateVal,notes:notes.substring(0,2000),
      });
      marked.add(activeCell.index);
      const cells=document.querySelectorAll('.sb-cell');
      if(cells[activeCell.index]){
        cells[activeCell.index].classList.remove('sb-partner');
        cells[activeCell.index].classList.add('sb-marked');
      }
      checkBingo();
      await api('/card','PUT',{ekb_marked:JSON.stringify([...marked]),ekb_bingos:totalBingos});
      checkAwards(); updateScore();
      sbEl('sb-submit-status').textContent='✓ Salvestatud!';

      // If EKB mode, open Vaatlusmäng panel after brief delay
      if(mode==='ekb'){
        pendingObsChurch=churchName;
        setTimeout(()=>{closeModal();openObsPanel(churchName,dateVal);},700);
      }else{
        setTimeout(()=>{closeModal();showToast('Külastus salvestatud ✓');},600);
      }
    }catch(e){
      sbEl('sb-submit-status').textContent='Viga: '+e.message;
      sbEl('sb-submit-btn').disabled=false;
    }
  }

  // ── Vaatlusmäng panel ────────────────────────────────────────
  function openObsPanel(churchName,visitDate){
    const overlay=sbEl('sb-obs-overlay');
    const nameEl=sbEl('sb-obs-church-name');
    const grid=sbEl('sb-obs-grid');
    if(!overlay||!grid) return;
    if(nameEl) nameEl.textContent=churchName;
    sbEl('sb-obs-notes').value='';
    sbEl('sb-obs-notes').placeholder=sbRandPrompt();

    // Render obs squares as checkboxes
    grid.innerHTML=SB_OIK_SQUARES.map((sq,i)=>`
      <label class="sb-obs-item">
        <input type="checkbox" name="obs_sq" value="${i}" data-label="${sbEsc(sq.label)}">
        <span class="sb-obs-icon">${sq.icon}</span>
        <span class="sb-obs-label">${sbEsc(sq.label)}</span>
      </label>
    `).join('');

    overlay.classList.add('sb-open');
    pendingObsChurch=churchName;
    // Store visit date for observations
    overlay.dataset.visitDate=visitDate;
  }

  async function submitObservations(){
    const overlay=sbEl('sb-obs-overlay');
    const churchName=pendingObsChurch;
    const visitDate=overlay?overlay.dataset.visitDate:sbToday();
    const notes=sbEl('sb-obs-notes').value.trim();
    const checked=[...document.querySelectorAll('#sb-obs-grid input[name="obs_sq"]:checked')];

    if(!checked.length&&!notes){closeObs();showToast('Külastus salvestatud ✓');return;}

    try{
      for(const cb of checked){
        const idx=parseInt(cb.value);
        const label=cb.dataset.label;
        const colLetter=SB_COL_LETTERS[idx%5];
        const rowNum=Math.floor(idx/5)+1;
        await api('/observe','POST',{
          church_name:churchName,square_num:colLetter+rowNum,
          square_label:label,visit_date:visitDate,notes:checked.length===1?notes:'',
        });
        obsMarked.add(idx);
      }
      // Submit general note as a separate obs record if multiple squares
      if(notes&&checked.length>1){
        await api('/observe','POST',{
          church_name:churchName,square_num:'N3',
          square_label:'Üldised märkused',visit_date:visitDate,notes,
        });
      }
      await api('/card','PUT',{obs_marked:JSON.stringify([...obsMarked])});
      updateScore();
    }catch(e){console.error('Obs error:',e);}
    closeObs();showToast('Vaatlused salvestatud ✓');
  }

  function closeObs(){
    const overlay=sbEl('sb-obs-overlay');
    if(overlay) overlay.classList.remove('sb-open');
    pendingObsChurch=null;
  }

  // ── Bingo / Awards ───────────────────────────────────────────
  function checkBingo(){
    SB_BINGO_LINES.forEach((line,li)=>{
      if(!bingoLines.has(li)&&line.every(i=>marked.has(i))){
        bingoLines.add(li);totalBingos++;
        const cells=document.querySelectorAll('.sb-cell');
        line.forEach(i=>{if(cells[i])cells[i].classList.add('sb-bingo-line');});
      }
    });
  }

  function checkAwards(){
    const visits=marked.size;
    SB_AWARDS.forEach((award,ai)=>{
      if(awardsGiven.has(ai)) return;
      if((award.visits===0||visits>=award.visits)&&(award.bingos===0||totalBingos>=award.bingos)){
        awardsGiven.add(ai);awardQueue.push(award);
      }
    });
    if(awardQueue.length) showNextAward();
  }

  function showNextAward(){
    if(!awardQueue.length) return;
    const a=awardQueue.shift();
    sbEl('sb-award-emblem').textContent=a.emblem;
    sbEl('sb-award-tier').textContent=a.tier;
    sbEl('sb-award-title').textContent=a.title;
    sbEl('sb-award-desc').textContent=a.desc;
    sbEl('sb-award-overlay').classList.add('sb-open');
  }

  function closeAward(){
    sbEl('sb-award-overlay').classList.remove('sb-open');
    setTimeout(()=>{if(awardQueue.length) showNextAward();},300);
  }

  function updateScore(){
    const v=sbEl('sb-score-visited');const b=sbEl('sb-score-bingo');
    const l=sbEl('sb-score-left');const o=sbEl('sb-score-obs');
    if(v) v.textContent=marked.size;
    if(b) b.textContent=totalBingos;
    if(l) l.textContent=25-marked.size;
    if(o) o.textContent=obsMarked.size;
  }

  function showToast(msg){
    const t=sbEl('sb-toast');if(!t) return;
    t.textContent=msg;t.classList.add('sb-show');
    setTimeout(()=>t.classList.remove('sb-show'),2600);
  }

  return{init,selectMode,onHomeChurchChange,register,startNewSeason,logout,showResume,sendResume,
    toggleRules,toggleHow,switchCard,submitVisit,closeModal,submitObservations,closeObs,closeAward};
})();

/* ═══════════════════════════════════════════════════════════════
   LEADERBOARD
═══════════════════════════════════════════════════════════════ */
const SuveBingoLB=(function(){
  let currentFilter='ekb';

  function setFilter(mode){
    currentFilter=mode;
    ['ekb','obs','all'].forEach(m=>{
      const btn=document.getElementById('sb-toggle-'+(m==='obs'?'obs':m));
      if(btn) btn.classList.toggle('sb-active',m===mode);
    });
    loadData();
  }

  function setTab(tab){
    ['players','cards','recent'].forEach(t=>{
      const tb=document.getElementById('sb-tab-'+t);
      const pn=document.getElementById('sb-pane-'+t);
      if(tb) tb.classList.toggle('sb-active',t===tab);
      if(pn) pn.classList.toggle('sb-active',t===tab);
    });
  }

  async function loadData(){
    try{
      const [lb,cards]=await Promise.all([
        fetch(SB_API+'/leaderboard?mode='+currentFilter).then(r=>r.json()),
        fetch(SB_API+'/top-cards').then(r=>r.json()),
      ]);
      renderStats(lb);renderLeaderboard(lb);renderCards(cards);renderRecent(cards.recent||[]);
      const lu=document.getElementById('sb-last-updated');
      if(lu) lu.textContent='Viimati uuendatud: '+new Date().toLocaleString('et-EE');
      // Update season tag
      const st=document.getElementById('sb-season-tag');
      if(st&&SB_GAME.gameYear) st.textContent='Suvi '+SB_GAME.gameYear;
    }catch(e){
      const lb=document.getElementById('sb-leaderboard-body');
      if(lb) lb.innerHTML='<div class="sb-error-msg">Andmete laadimine ebaõnnestus.</div>';
    }
  }

  function renderStats(data){
    const s=data.stats||{};
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v||'0';};
    set('sb-stat-participants',s.participants);set('sb-stat-visits',s.visits);
    set('sb-stat-churches',s.churches);set('sb-stat-complete',s.complete);
    set('sb-count-ekb',data.ekb_count);set('sb-count-obs',data.obs_count);
  }

  function renderLeaderboard(data){
    const body=document.getElementById('sb-leaderboard-body');
    if(!body) return;
    const players=data.players||[];
    if(!players.length){body.innerHTML='<div class="sb-error-msg">Veel pole osalejaid.</div>';return;}
    const showPill=currentFilter==='all';
    let html=`<table class="sb-lb-table"><thead><tr><th>#</th><th>Mängija</th><th class="sb-center">Külastused</th><th class="sb-center">Vaatlused</th></tr></thead><tbody>`;
    players.forEach((p,i)=>{
      const rank=i+1;
      const visits=parseInt(p.ekb_visits)||0;
      const obs=parseInt(p.obs_visits)||0;
      const pct=Math.min(100,Math.round((visits/25)*100));
      const pill=showPill?`<span class="sb-mode-pill ${p.mode==='ekb'?'ekb':'oik'}">${p.mode==='ekb'?'EKB':'Vaatlus'}</span>`:'';
      const badge=visits>=24?`<span class="sb-complete-badge">Täis!</span>`:'';
      const last=p.last_visit_at?`<span class="sb-last-visit">${p.last_visit_at.slice(0,10)}</span>`:'';
      html+=`<tr><td class="sb-rank-cell ${rank<=3?'sb-rank-'+rank:''}">${rank}</td>
        <td class="sb-name-cell">${sbEsc(p.name||'—')}${pill}${badge}${last}</td>
        <td class="sb-center">${visits}</td>
        <td class="sb-center">${obs}</td></tr>`;
    });
    html+='</tbody></table>';
    body.innerHTML=html;
  }

  function cardRow(item,rank,max,mode){
    const pct=Math.round((parseInt(item.visits)/max)*100);
    return`<div class="sb-card-row">
      <div class="sb-card-rank ${rank<=3?'sb-r'+rank:''}">${rank}</div>
      <div class="sb-card-info">
        <div class="sb-card-name" title="${sbEsc(item.name)}">${sbEsc(item.name)}</div>
        <div class="sb-card-bar-row"><div class="sb-card-bar-track"><div class="sb-card-bar-fill ${mode}" style="width:${pct}%"></div></div></div>
      </div>
      <div class="sb-card-count ${mode}">${item.visits}</div>
    </div>`;
  }

  function renderCards(data){
    const ekbTop=data.ekb||[];const obsTop=data.obs||[];
    const ekbMax=ekbTop.length?parseInt(ekbTop[0].visits):1;
    const obsMax=obsTop.length?parseInt(obsTop[0].visits):1;
    const eb=document.getElementById('sb-ekb-cards-body');
    const ob=document.getElementById('sb-oik-cards-body');
    if(eb) eb.innerHTML=ekbTop.length?ekbTop.map((r,i)=>cardRow(r,i+1,ekbMax,'ekb')).join(''):'<div class="sb-error-msg">Veel pole EKB külastusi.</div>';
    if(ob) ob.innerHTML=obsTop.length?obsTop.map((r,i)=>cardRow(r,i+1,obsMax,'oik')).join(''):'<div class="sb-error-msg">Veel pole vaatlusmärgiseid.</div>';
  }

  function renderRecent(visits){
    const body=document.getElementById('sb-visits-body');
    if(!body) return;
    if(!visits.length){body.innerHTML='<div class="sb-error-msg">Veel pole külastusi.</div>';return;}
    body.innerHTML=visits.map(v=>{
      const icon=v.mode==='ekb'?'⛪':'🔍';
      const pill=`<span class="sb-mode-pill ${v.mode==='ekb'?'ekb':'oik'}" style="margin:0">${v.mode==='ekb'?'EKB':'Vaatlus'}</span>`;
      const notes=v.notes?`<div class="sb-visit-notes">"${sbEsc(v.notes)}"</div>`:'';
      return`<div class="sb-visit-entry">
        <div class="sb-visit-icon">${icon}</div>
        <div class="sb-visit-body">
          <div class="sb-visit-church">${sbEsc(v.church_name||'—')}</div>
          <div class="sb-visit-square">${sbEsc(v.square_label||'')}</div>${notes}
        </div>
        <div class="sb-visit-meta">${sbEsc(v.player||'')}<br>${sbEsc(v.visit_date||'')}<br>${pill}</div>
      </div>`;
    }).join('');
  }

  return{setFilter,setTab,loadData};
})();

/* ── Init ── */
document.addEventListener('DOMContentLoaded',function(){
  if(document.getElementById('suvebingo-app'))        SuveBingo.init();
  if(document.getElementById('suvebingo-leaderboard')) SuveBingoLB.loadData();
});
