<?php
defined( 'ABSPATH' ) || exit;

function suvebingo_create_tables() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // ── Games ──────────────────────────────────────────────────
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_games (
        id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        year       SMALLINT(4) UNSIGNED NOT NULL,
        name       VARCHAR(120) NOT NULL DEFAULT '',
        start_date DATE NOT NULL,
        end_date   DATE NOT NULL,
        active     TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY year (year)
    ) $c;" );

    // ── Prayer partners per game year ──────────────────────────
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_partners (
        id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        game_id     BIGINT(20) UNSIGNED NOT NULL,
        church_a    VARCHAR(200) NOT NULL DEFAULT '',
        church_b    VARCHAR(200) NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY game_id (game_id),
        KEY church_a (church_a(40))
    ) $c;" );

    // ── Church directory (seeded from code, editable in admin) ─
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_churches (
        id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name         VARCHAR(200) NOT NULL DEFAULT '',
        region       VARCHAR(60)  NOT NULL DEFAULT '',
        ekb_url      VARCHAR(400) NOT NULL DEFAULT '',
        address      VARCHAR(300) NOT NULL DEFAULT '',
        pastor       VARCHAR(120) NOT NULL DEFAULT '',
        phone        VARCHAR(40)  NOT NULL DEFAULT '',
        email        VARCHAR(120) NOT NULL DEFAULT '',
        notes        TEXT,
        in_ekb_pool  TINYINT(1) NOT NULL DEFAULT 1,
        manual_entry TINYINT(1) NOT NULL DEFAULT 0,
        updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY name (name(80)),
        KEY region (region),
        KEY in_ekb_pool (in_ekb_pool)
    ) $c;" );

    // ── Participants ───────────────────────────────────────────
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_participants (
        id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        game_id       BIGINT(20) UNSIGNED NOT NULL,
        name          VARCHAR(120) NOT NULL DEFAULT '',
        display_name  VARCHAR(80)  NOT NULL DEFAULT '',
        email         VARCHAR(200) NOT NULL DEFAULT '',
        home_church   VARCHAR(200) NOT NULL DEFAULT '',
        mode          VARCHAR(10)  NOT NULL DEFAULT 'ekb',
        partner       VARCHAR(200) NOT NULL DEFAULT '',
        token_hash    VARCHAR(64)  NOT NULL DEFAULT '',
        ekb_card_json LONGTEXT,
        ekb_marked    TEXT,
        obs_marked    TEXT,
        ekb_bingos    SMALLINT(5) UNSIGNED NOT NULL DEFAULT 0,
        ekb_visits    SMALLINT(5) UNSIGNED NOT NULL DEFAULT 0,
        obs_visits    SMALLINT(5) UNSIGNED NOT NULL DEFAULT 0,
        registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_visit_at DATETIME DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY token_hash (token_hash),
        KEY email_game (email(30), game_id),
        KEY game_id (game_id),
        KEY mode (mode)
    ) $c;" );

    // ── EKB visits ─────────────────────────────────────────────
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_visits (
        id             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        participant_id BIGINT(20) UNSIGNED NOT NULL,
        game_id        BIGINT(20) UNSIGNED NOT NULL,
        church_name    VARCHAR(200) NOT NULL DEFAULT '',
        square_num     VARCHAR(10)  NOT NULL DEFAULT '',
        visit_date     DATE NOT NULL,
        notes          TEXT,
        submitted_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY participant_id (participant_id),
        KEY game_id (game_id),
        KEY church_name (church_name(40)),
        KEY visit_date (visit_date)
    ) $c;" );

    // ── Vaatlusmäng observations (qualitative markers per visit) ─
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_observations (
        id             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        participant_id BIGINT(20) UNSIGNED NOT NULL,
        game_id        BIGINT(20) UNSIGNED NOT NULL,
        church_name    VARCHAR(200) NOT NULL DEFAULT '',
        square_num     VARCHAR(10)  NOT NULL DEFAULT '',
        square_label   VARCHAR(300) NOT NULL DEFAULT '',
        visit_date     DATE NOT NULL,
        notes          TEXT,
        submitted_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY participant_id (participant_id),
        KEY game_id (game_id),
        KEY church_name (church_name(40)),
        KEY square_label (square_label(60))
    ) $c;" );

    // ── Testimonials ───────────────────────────────────────────
    dbDelta( "CREATE TABLE {$wpdb->prefix}suvebingo_testimonials (
        id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        quote      TEXT NOT NULL,
        author     VARCHAR(200) NOT NULL DEFAULT '',
        active     TINYINT(1) NOT NULL DEFAULT 1,
        sort_order SMALLINT(5) UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY active (active)
    ) $c;" );

    update_option( 'suvebingo_db_version', SUVEBINGO_DB_VER );
}

add_action( 'plugins_loaded', function() {
    if ( get_option( 'suvebingo_db_version' ) !== SUVEBINGO_DB_VER ) {
        suvebingo_create_tables();
        suvebingo_seed_churches();
    }
} );

// ── Seed church directory on first activation ──────────────────
function suvebingo_seed_churches() {
    global $wpdb;
    $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_churches" );
    if ( $count > 0 ) return; // already seeded

    $churches = suvebingo_church_data();
    foreach ( $churches as $c ) {
        $wpdb->insert(
            $wpdb->prefix . 'suvebingo_churches',
            [
                'name'         => $c['name'],
                'region'       => $c['region'],
                'ekb_url'      => $c['url'] ?? '',
                'in_ekb_pool'  => $c['pool'] ? 1 : 0,
                'manual_entry' => empty( $c['url'] ) ? 1 : 0,
            ],
            [ '%s','%s','%s','%d','%d' ]
        );
    }
}

// ── Master church data array ───────────────────────────────────
function suvebingo_church_data() {
    return [
        // Harjumaa/Kesk
        ['name'=>'Kehra Kogudus',                        'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/kehra-kogudus/','pool'=>true],
        ['name'=>'Keila Baptisti Kogudus',               'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/keila-baptisti-kogudus/','pool'=>true],
        ['name'=>'Koeru Vabakogudus',                    'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/koeru-vabakogudus/','pool'=>true],
        ['name'=>'Kohila Baptistikogudus',               'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/kohila-baptistikogudus/','pool'=>true],
        ['name'=>'Laitse Kogudus',                       'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/laitse-kogudus/','pool'=>true],
        ['name'=>'Loksa Baptisti Kogudus',               'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/loksa-baptisti-kogudus/','pool'=>true],
        ['name'=>'Märjamaa Vabakogudus',                 'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/marjamaa-vabakogudus/','pool'=>true],
        ['name'=>'Paide Baptistikogudus',                'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/paide-baptistikogudus/','pool'=>true],
        ['name'=>'Rapla Vabakogudus',                    'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/rapla-vabakogudus/','pool'=>true],
        ['name'=>'Valkla Baptistikogudus',               'region'=>'Harjumaa/Kesk','url'=>'https://kogudused.ee/valkla-baptistikogudus/','pool'=>true],
        ['name'=>'Järvekandi Uue Alguse Kogudus',        'region'=>'Harjumaa/Kesk','url'=>'','pool'=>true],
        // Edela-Eesti
        ['name'=>'3D Kogudus',                           'region'=>'Edela-Eesti','url'=>'https://kogudused.ee/3d-kogudus/','pool'=>true],
        ['name'=>'EK Suigu Kogudus',                    'region'=>'Edela-Eesti','url'=>'https://kogudused.ee/evangeeliumi-kristlaste-suigu-kogudus/','pool'=>true],
        ['name'=>'Kilingi-Nõmme Vabakogudus',           'region'=>'Edela-Eesti','url'=>'https://kogudused.ee/kilingi-nomme-vabakogudus/','pool'=>true],
        ['name'=>'Suure-Jaani Baptisti Kogudus',        'region'=>'Edela-Eesti','url'=>'https://kogudused.ee/suure-jaani-baptisti-kogudus/','pool'=>true],
        // Lõuna-Eesti
        ['name'=>'Antsla EKB Kogudus',                  'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/antsla-evangeeliumi-kristlaste-ja-baptistide-kogudus/','pool'=>true],
        ['name'=>'Elva Baptistikogudus',                'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/elva-baptistikogudus/','pool'=>true],
        ['name'=>'Jõgeva Baptistikogudus',              'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/jogeva-baptistikogudus/','pool'=>true],
        ['name'=>'Mooste Baptistikogudus',              'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/mooste-baptistikogudus/','pool'=>true],
        ['name'=>'Otepää EV "Palverändur"',             'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/otepaa-evangeelne-vabakogudus-palverandur/','pool'=>true],
        ['name'=>'Puka Vabakogudus',                    'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/puka-vabakogudus/','pool'=>true],
        ['name'=>'Sadala Baptisti Kogudus',             'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/sadala-baptisti-kogudus/','pool'=>true],
        ['name'=>'Selise Baptistikogudus',              'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/selise-baptistikogudus/','pool'=>true],
        ['name'=>'Tõrva Immaanueli Kogudus',           'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/torva-immaanueli-kogudus/','pool'=>true],
        ['name'=>'Valga Betaania Baptistikogudus',     'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/valga-betaania-baptistikogudus/','pool'=>true],
        ['name'=>'Valga Peeteli EKB Kogudus',         'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/valga-peeteli-ekb-kogudus/','pool'=>true],
        ['name'=>'Viljandi Baptistikogudus',           'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/viljandi-baptistikogudus/','pool'=>true],
        ['name'=>'Võru Baptisti Kogudus',              'region'=>'Lõuna-Eesti','url'=>'https://kogudused.ee/voru-baptisti-kogudus/','pool'=>true],
        // Virumaa
        ['name'=>'Avispea Vabakogudus',                'region'=>'Virumaa','url'=>'https://kogudused.ee/avispea-vabakogudus/','pool'=>true],
        ['name'=>'Kohtla-Järve Saaroni Baptisti Kogudus','region'=>'Virumaa','url'=>'https://kogudused.ee/saaroni-baptisti-kogudus/','pool'=>true],
        ['name'=>'Mustvee Betaania Kogudus',           'region'=>'Virumaa','url'=>'https://kogudused.ee/mustvee-betaania-kogudus/','pool'=>true],
        ['name'=>'Rakke Kogudus',                      'region'=>'Virumaa','url'=>'https://kogudused.ee/rakke-kogudus/','pool'=>true],
        ['name'=>'Tapa Elava Usu Kogudus',            'region'=>'Virumaa','url'=>'https://kogudused.ee/tapa-elava-usu-kogudus/','pool'=>true],
        // Läänemaa
        ['name'=>'Haapsalu Baptistikogudus',          'region'=>'Läänemaa','url'=>'https://kogudused.ee/haapsalu-baptistikogudus/','pool'=>true],
        ['name'=>'Lihula Baptistikogudus',            'region'=>'Läänemaa','url'=>'https://kogudused.ee/lihula-baptistikogudus/','pool'=>true],
        ['name'=>'Mäevalla palvela',                  'region'=>'Läänemaa','url'=>'https://kogudused.ee/ridala-baptisti-koguduse-maevalla-toopunkt/','pool'=>true],
        ['name'=>'Palivere EKV Kogudus',             'region'=>'Läänemaa','url'=>'https://kogudused.ee/palivere-evangeeliumi-kristlaste-vabakogudus/','pool'=>true],
        ['name'=>'Ridala Baptisti Kogudus',          'region'=>'Läänemaa','url'=>'https://kogudused.ee/ridala-baptisti-kogudus/','pool'=>true],
        ['name'=>'Sutlepa Baptisti Kogudus',         'region'=>'Läänemaa','url'=>'https://kogudused.ee/sutlepa-baptisti-kogudus/','pool'=>true],
        ['name'=>'Vormsi Rälby Baptisti Kogudus',    'region'=>'Läänemaa','url'=>'https://kogudused.ee/vormsi-ralby-baptistikogudus/','pool'=>true],
        // Hiiumaa
        ['name'=>'Emmaste-Nurste Kogudus',           'region'=>'Hiiumaa','url'=>'https://kogudused.ee/emmaste-nurste-kogudus/','pool'=>true],
        ['name'=>'Harju EKB Kogudus',               'region'=>'Hiiumaa','url'=>'https://kogudused.ee/harju-evangeeliumi-kristlaste-ja-baptistide-kogudus/','pool'=>true],
        ['name'=>'Hiiumaa Kristlik Misjonikogudus', 'region'=>'Hiiumaa','url'=>'https://kogudused.ee/hiiumaa-kristlik-misjonikogudus/','pool'=>true],
        ['name'=>'Hilleste Kristlik Kogudus',       'region'=>'Hiiumaa','url'=>'https://kogudused.ee/hilleste-kristlik-kogudus/','pool'=>true],
        ['name'=>'Jausa Kogudus',                   'region'=>'Hiiumaa','url'=>'https://kogudused.ee/jausa-kogudus/','pool'=>true],
        ['name'=>'Käina EKB Kogudus',              'region'=>'Hiiumaa','url'=>'https://kogudused.ee/kaina-evangeeliumi-kristlaste-ja-baptistide-kogudus/','pool'=>true],
        ['name'=>'Kärdla Baptistikogudus',         'region'=>'Hiiumaa','url'=>'https://kogudused.ee/kardla-baptistikogudus/','pool'=>true],
        ['name'=>'Lauka palvela',                  'region'=>'Hiiumaa','url'=>'https://kogudused.ee/lauka-kardla-baptistikoguduse-osakond/','pool'=>true],
        ['name'=>'Luguse Kogudus',                 'region'=>'Hiiumaa','url'=>'https://kogudused.ee/luguse-ekb-kogudus/','pool'=>true],
        ['name'=>'Palade Priikogudus',             'region'=>'Hiiumaa','url'=>'https://kogudused.ee/palade-priikogudus/','pool'=>true],
        ['name'=>'Ühtri palvela',                 'region'=>'Hiiumaa','url'=>'https://kogudused.ee/uhtri-palvela-kaina-evangeeliumi-kristlaste-ja-baptistide-kogudus/','pool'=>true],
        // Saaremaa
        ['name'=>'Eikla Priikogudus',             'region'=>'Saaremaa','url'=>'https://kogudused.ee/eikla-priikogudus/','pool'=>true],
        ['name'=>'Kuressaare Siioni Kogudus',     'region'=>'Saaremaa','url'=>'https://kogudused.ee/kuressaare-siioni-kogudus/','pool'=>true],
        ['name'=>'Leisi Baptisti Kogudus',        'region'=>'Saaremaa','url'=>'https://kogudused.ee/leisi-baptisti-kogudus/','pool'=>true],
        ['name'=>'Meiuste EKB Kogudus',          'region'=>'Saaremaa','url'=>'https://kogudused.ee/meiuste-ekb-kogudus/','pool'=>true],
        ['name'=>'Valjala Rahu Vabakogudus',     'region'=>'Saaremaa','url'=>'https://kogudused.ee/valjala-rahu-vabakogudus/','pool'=>true],
        // Church plants — manual entry required
        ['name'=>'K13',                           'region'=>'Tallinn','url'=>'','pool'=>true],
        ['name'=>'Ühisosa',                       'region'=>'Tallinn','url'=>'','pool'=>true],
        ['name'=>'Tallinna Korea Kogudus',        'region'=>'Tallinn','url'=>'','pool'=>true],
    ];
}
