<?php
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', 'suvebingo_admin_menu' );

function suvebingo_admin_menu() {
    add_menu_page( 'Suvebingo', 'Suvebingo', 'manage_options', 'suvebingo', 'suvebingo_admin_dashboard', 'dashicons-awards', 30 );
    add_submenu_page( 'suvebingo', 'Mängud',        'Mängud',        'manage_options', 'suvebingo-games',        'suvebingo_admin_games' );
    add_submenu_page( 'suvebingo', 'Palvepartnerid','Palvepartnerid','manage_options', 'suvebingo-partners',     'suvebingo_admin_partners' );
    add_submenu_page( 'suvebingo', 'Kogudused',     'Kogudused',     'manage_options', 'suvebingo-churches',     'suvebingo_admin_churches' );
    add_submenu_page( 'suvebingo', 'Osalejad',      'Osalejad',      'manage_options', 'suvebingo-participants', 'suvebingo_admin_participants' );
    add_submenu_page( 'suvebingo', 'Külastused',    'Külastused',    'manage_options', 'suvebingo-visits',       'suvebingo_admin_visits' );
    add_submenu_page( 'suvebingo', 'Aruanded',      'Aruanded',      'manage_options', 'suvebingo-reports',      'suvebingo_admin_reports' );
    add_submenu_page( 'suvebingo', 'Tunnistused',   'Tunnistused',   'manage_options', 'suvebingo-testimonials', 'suvebingo_admin_testimonials' );
    add_submenu_page( 'suvebingo', 'Eksport',       'Eksport',       'manage_options', 'suvebingo-export',       'suvebingo_admin_export' );
}

// ── Helper ─────────────────────────────────────────────────────
function sb_nonce( $action ) { return wp_create_nonce( 'suvebingo_' . $action ); }
function sb_verify( $action ) {
    if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'suvebingo_' . $action ) )
        wp_die( 'Kehtetu nonce.' );
}
function sb_cap() { if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Juurdepääs keelatud.' ); }

// ── Dashboard ──────────────────────────────────────────────────
function suvebingo_admin_dashboard() {
    sb_cap();
    global $wpdb;
    $game     = suvebingo_get_active_game();
    $total_p  = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_participants");
    $total_v  = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_visits");
    $total_o  = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_observations");
    $churches = (int)$wpdb->get_var("SELECT COUNT(DISTINCT church_name) FROM {$wpdb->prefix}suvebingo_visits");
    ?>
    <div class="wrap">
        <h1>Suvebingo <?php echo $game ? esc_html($game->year) : ''; ?></h1>
        <?php if($game): ?>
        <p style="color:#666;margin-bottom:1rem"><?php echo esc_html($game->start_date); ?> – <?php echo esc_html($game->end_date); ?></p>
        <?php else: ?>
        <div class="notice notice-warning"><p>Aktiivset mängu pole. <a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-games')); ?>">Loo mäng →</a></p></div>
        <?php endif; ?>
        <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;margin:1.5rem 0">
            <?php foreach([['Osalejaid',$total_p],['EKB külastust',$total_v],['Vaatlusi',$total_o],['Kogudust külastatud',$churches]] as $s): ?>
            <div style="background:#fff;border:1px solid #ddd;padding:1.2rem;text-align:center;border-radius:4px">
                <strong style="display:block;font-size:2rem;color:#8b3a1a"><?php echo esc_html($s[1]); ?></strong>
                <span style="font-size:0.85rem;color:#666"><?php echo esc_html($s[0]); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <p>
            <?php foreach([['suvebingo-games'=>'Mängud'],['suvebingo-partners'=>'Palvepartnerid'],['suvebingo-churches'=>'Kogudused'],['suvebingo-reports'=>'Aruanded'],['suvebingo-export'=>'Eksport']] as $page=>$label): ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page='.$page)); ?>" class="button" style="margin-right:0.5rem"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </p>
    </div>
    <?php
}

// ── Games ──────────────────────────────────────────────────────
function suvebingo_admin_games() {
    sb_cap(); global $wpdb;

    if ( isset($_POST['sb_save_game']) ) {
        sb_verify('game');
        $year  = (int)($_POST['year'] ?? date('Y'));
        $name  = sanitize_text_field($_POST['game_name'] ?? '');
        $start = sanitize_text_field($_POST['start_date'] ?? '');
        $end   = sanitize_text_field($_POST['end_date'] ?? '');
        if($name && $start && $end) {
            $id = (int)($_POST['game_id'] ?? 0);
            if($id) {
                $wpdb->update("{$wpdb->prefix}suvebingo_games",['year'=>$year,'name'=>$name,'start_date'=>$start,'end_date'=>$end],['id'=>$id],['%d','%s','%s','%s'],['%d']);
            } else {
                $wpdb->insert("{$wpdb->prefix}suvebingo_games",['year'=>$year,'name'=>$name,'start_date'=>$start,'end_date'=>$end,'active'=>0],['%d','%s','%s','%s','%d']);
            }
            echo '<div class="notice notice-success"><p>Mäng salvestatud.</p></div>';
        }
    }
    if ( isset($_POST['sb_activate_game']) ) {
        sb_verify('game');
        $id = (int)($_POST['game_id'] ?? 0);
        if($id) {
            $wpdb->query("UPDATE {$wpdb->prefix}suvebingo_games SET active=0");
            $wpdb->update("{$wpdb->prefix}suvebingo_games",['active'=>1],['id'=>$id],['%d'],['%d']);
            echo '<div class="notice notice-success"><p>Mäng aktiveeritud.</p></div>';
        }
    }

    $games = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}suvebingo_games ORDER BY year DESC");
    $nonce = sb_nonce('game');
    ?>
    <div class="wrap">
        <h1>Mängud</h1>
        <h2>Lisa uus mäng</h2>
        <form method="POST">
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>">
            <input type="hidden" name="game_id" value="0">
            <table class="form-table">
                <tr><th><label for="year">Aasta</label></th><td><input name="year" type="number" value="<?php echo esc_attr(date('Y')+1); ?>" min="2024" max="2040" class="small-text"></td></tr>
                <tr><th><label for="game_name">Mängu nimi</label></th><td><input name="game_name" type="text" class="regular-text" placeholder="Suvebingo 2027"></td></tr>
                <tr><th><label for="start_date">Alguskuupäev</label></th><td><input name="start_date" type="date" value="<?php echo esc_attr((date('Y')+1).'-06-01'); ?>"></td></tr>
                <tr><th><label for="end_date">Lõppkuupäev</label></th><td><input name="end_date" type="date" value="<?php echo esc_attr((date('Y')+1).'-08-31'); ?>"></td></tr>
            </table>
            <p><button type="submit" name="sb_save_game" class="button button-primary">Salvesta mäng</button></p>
        </form>
        <h2>Kõik mängud</h2>
        <table class="widefat striped">
            <thead><tr><th>Aasta</th><th>Nimi</th><th>Algus</th><th>Lõpp</th><th>Olek</th><th>Toimingud</th></tr></thead>
            <tbody>
            <?php foreach($games as $g): ?>
            <tr>
                <td><?php echo esc_html($g->year); ?></td>
                <td><?php echo esc_html($g->name); ?></td>
                <td><?php echo esc_html($g->start_date); ?></td>
                <td><?php echo esc_html($g->end_date); ?></td>
                <td><?php echo $g->active ? '<span style="color:green;font-weight:600">✓ Aktiivne</span>' : '—'; ?></td>
                <td>
                    <?php if(!$g->active): ?>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>">
                        <input type="hidden" name="game_id" value="<?php echo esc_attr($g->id); ?>">
                        <button type="submit" name="sb_activate_game" class="button button-small">Aktiveeri</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ── Prayer partners ────────────────────────────────────────────
function suvebingo_admin_partners() {
    sb_cap(); global $wpdb;
    $games = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}suvebingo_games ORDER BY year DESC");
    $game_id = isset($_GET['game_id']) ? (int)$_GET['game_id'] : ($games ? (int)$games[0]->id : 0);

    if ( isset($_POST['sb_save_partners']) ) {
        sb_verify('partners');
        $gid   = (int)($_POST['game_id'] ?? 0);
        $pairs = sanitize_textarea_field(wp_unslash($_POST['pairs'] ?? ''));
        if($gid) {
            $wpdb->delete("{$wpdb->prefix}suvebingo_partners",['game_id'=>$gid],['%d']);
            foreach(array_filter(array_map('trim', explode("\n", $pairs))) as $line) {
                $parts = array_map('trim', explode('|', $line));
                if(count($parts) === 2 && $parts[0] && $parts[1]) {
                    $wpdb->insert("{$wpdb->prefix}suvebingo_partners",['game_id'=>$gid,'church_a'=>$parts[0],'church_b'=>$parts[1]],['%d','%s','%s']);
                    $wpdb->insert("{$wpdb->prefix}suvebingo_partners",['game_id'=>$gid,'church_a'=>$parts[1],'church_b'=>$parts[0]],['%d','%s','%s']);
                }
            }
            echo '<div class="notice notice-success"><p>Palvepartnerid salvestatud.</p></div>';
        }
    }

    $pairs = $game_id ? $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT LEAST(church_a,church_b) AS a, GREATEST(church_a,church_b) AS b
         FROM {$wpdb->prefix}suvebingo_partners WHERE game_id=%d ORDER BY a", $game_id
    )) : [];
    $pairs_text = implode("\n", array_map(fn($r)=>$r->a.'|'.$r->b, $pairs));
    ?>
    <div class="wrap">
        <h1>Palvepartnerid</h1>
        <p>Sisesta iga paar ühele reale kujul: <code>Kogudus A | Kogudus B</code>. Nimed peavad täpselt vastama koguduste kataloogis olevatele nimedele.</p>
        <form method="POST">
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr(sb_nonce('partners')); ?>">
            <table class="form-table">
                <tr><th><label for="game_id">Mäng</label></th>
                    <td><select name="game_id" onchange="this.form.submit()">
                        <?php foreach($games as $g): ?>
                        <option value="<?php echo esc_attr($g->id); ?>" <?php selected($g->id,$game_id); ?>><?php echo esc_html($g->name); ?></option>
                        <?php endforeach; ?>
                    </select></td></tr>
                <tr><th><label for="pairs">Paarid</label></th>
                    <td><textarea name="pairs" rows="40" class="large-text" style="font-family:monospace;font-size:0.85rem"><?php echo esc_textarea($pairs_text); ?></textarea>
                    <p class="description"><?php echo count($pairs); ?> paari</p></td></tr>
            </table>
            <p><button type="submit" name="sb_save_partners" class="button button-primary">Salvesta</button></p>
        </form>
    </div>
    <?php
}

// ── Church directory ───────────────────────────────────────────
function suvebingo_admin_churches() {
    sb_cap(); global $wpdb;

    if ( isset($_POST['sb_save_church']) ) {
        sb_verify('church');
        $id      = (int)($_POST['church_id'] ?? 0);
        $data    = [
            'name'        => sanitize_text_field($_POST['church_name'] ?? ''),
            'region'      => sanitize_text_field($_POST['region'] ?? ''),
            'ekb_url'     => esc_url_raw($_POST['ekb_url'] ?? ''),
            'address'     => sanitize_text_field($_POST['address'] ?? ''),
            'pastor'      => sanitize_text_field($_POST['pastor'] ?? ''),
            'phone'       => sanitize_text_field($_POST['phone'] ?? ''),
            'email'       => sanitize_email($_POST['church_email'] ?? ''),
            'notes'       => sanitize_textarea_field($_POST['notes'] ?? ''),
            'in_ekb_pool' => isset($_POST['in_ekb_pool']) ? 1 : 0,
            'manual_entry'=> 1,
        ];
        $fmt = ['%s','%s','%s','%s','%s','%s','%s','%s','%d','%d'];
        if($id) {
            $wpdb->update("{$wpdb->prefix}suvebingo_churches",$data,['id'=>$id],$fmt,['%d']);
        } else {
            $wpdb->insert("{$wpdb->prefix}suvebingo_churches",$data,$fmt);
        }
        echo '<div class="notice notice-success"><p>Kogudus salvestatud.</p></div>';
    }

    $edit_id = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
    $editing = $edit_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}suvebingo_churches WHERE id=%d",$edit_id)) : null;
    $churches= $wpdb->get_results("SELECT * FROM {$wpdb->prefix}suvebingo_churches ORDER BY region,name");
    $nonce   = sb_nonce('church');
    ?>
    <div class="wrap">
        <h1>Koguduste kataloog</h1>
        <h2><?php echo $editing ? 'Muuda kogudust' : 'Lisa kogudus'; ?></h2>
        <form method="POST">
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>">
            <input type="hidden" name="church_id" value="<?php echo esc_attr($editing ? $editing->id : 0); ?>">
            <table class="form-table">
                <tr><th>Nimi *</th><td><input name="church_name" type="text" class="regular-text" value="<?php echo esc_attr($editing->name??''); ?>" required></td></tr>
                <tr><th>Regioon</th><td><select name="region">
                    <?php foreach(['Harjumaa/Kesk','Edela-Eesti','Lõuna-Eesti','Virumaa','Läänemaa','Hiiumaa','Saaremaa','Tallinn','Muu'] as $r): ?>
                    <option value="<?php echo esc_attr($r); ?>" <?php selected(($editing->region??''),$r); ?>><?php echo esc_html($r); ?></option>
                    <?php endforeach; ?>
                </select></td></tr>
                <tr><th>kogudused.ee URL</th><td><input name="ekb_url" type="url" class="large-text" value="<?php echo esc_attr($editing->ekb_url??''); ?>"></td></tr>
                <tr><th>Aadress</th><td><input name="address" type="text" class="regular-text" value="<?php echo esc_attr($editing->address??''); ?>"></td></tr>
                <tr><th>Pastor</th><td><input name="pastor" type="text" class="regular-text" value="<?php echo esc_attr($editing->pastor??''); ?>"></td></tr>
                <tr><th>Telefon</th><td><input name="phone" type="text" class="regular-text" value="<?php echo esc_attr($editing->phone??''); ?>"></td></tr>
                <tr><th>E-post</th><td><input name="church_email" type="email" class="regular-text" value="<?php echo esc_attr($editing->email??''); ?>"></td></tr>
                <tr><th>Märkused</th><td><textarea name="notes" rows="3" class="large-text"><?php echo esc_textarea($editing->notes??''); ?></textarea></td></tr>
                <tr><th>EKB mängu kaardis</th><td><label><input name="in_ekb_pool" type="checkbox" <?php checked(($editing->in_ekb_pool??1),1); ?>> Jah</label></td></tr>
            </table>
            <p>
                <button type="submit" name="sb_save_church" class="button button-primary">Salvesta</button>
                <?php if($editing): ?><a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-churches')); ?>" class="button">Tühista</a><?php endif; ?>
            </p>
        </form>

        <h2>Kogudused (<?php echo count($churches); ?>)</h2>
        <table class="widefat striped">
            <thead><tr><th>Nimi</th><th>Regioon</th><th>Pastor</th><th>URL</th><th>Käsitsi</th><th>Kaardis</th><th></th></tr></thead>
            <tbody>
            <?php foreach($churches as $c): ?>
            <tr>
                <td><?php echo esc_html($c->name); ?></td>
                <td><?php echo esc_html($c->region); ?></td>
                <td><?php echo esc_html($c->pastor); ?></td>
                <td><?php if($c->ekb_url): ?><a href="<?php echo esc_url($c->ekb_url); ?>" target="_blank">↗</a><?php else: ?>—<?php endif; ?></td>
                <td><?php echo $c->manual_entry ? '✎' : ''; ?></td>
                <td><?php echo $c->in_ekb_pool ? '✓' : ''; ?></td>
                <td><a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-churches&edit='.$c->id)); ?>" class="button button-small">Muuda</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ── Participants ───────────────────────────────────────────────
function suvebingo_admin_participants() {
    sb_cap(); global $wpdb;
    $game = suvebingo_get_active_game();
    $gid  = $game ? $game->id : 0;
    $rows = $gid ? $wpdb->get_results($wpdb->prepare(
        "SELECT id,display_name,name,email,home_church,mode,partner,ekb_visits,obs_visits,ekb_bingos,registered_at,last_visit_at
         FROM {$wpdb->prefix}suvebingo_participants WHERE game_id=%d ORDER BY ekb_visits DESC,last_visit_at DESC",$gid)) : [];
    ?>
    <div class="wrap">
        <h1>Osalejad <?php echo $game ? '('.esc_html($game->name).')' : ''; ?> (<?php echo count($rows); ?>)</h1>
        <table class="widefat striped">
            <thead><tr><th>#</th><th>Kuvanimi</th><th>Nimi</th><th>E-post</th><th>Kodukogudus</th><th>Partner</th><th>Mäng</th><th>EKB</th><th>Vaatlus</th><th>Bingo</th><th>Registreeritud</th></tr></thead>
            <tbody>
            <?php foreach($rows as $r): ?>
            <tr>
                <td><?php echo esc_html($r->id); ?></td>
                <td><?php echo esc_html($r->display_name); ?></td>
                <td><?php echo esc_html($r->name); ?></td>
                <td><?php echo esc_html($r->email); ?></td>
                <td><?php echo esc_html($r->home_church); ?></td>
                <td><?php echo esc_html($r->partner); ?></td>
                <td><span style="background:<?php echo $r->mode==='ekb'?'#3a5c2e':'#8b3a1a';?>;color:#fff;padding:2px 6px;border-radius:3px;font-size:0.8em"><?php echo esc_html(strtoupper($r->mode)); ?></span></td>
                <td><?php echo esc_html($r->ekb_visits); ?></td>
                <td><?php echo esc_html($r->obs_visits); ?></td>
                <td><?php echo esc_html($r->ekb_bingos); ?></td>
                <td><?php echo esc_html(substr($r->registered_at,0,10)); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ── Visits ─────────────────────────────────────────────────────
function suvebingo_admin_visits() {
    sb_cap(); global $wpdb;
    $game = suvebingo_get_active_game();
    $gid  = $game ? $game->id : 0;
    $rows = $gid ? $wpdb->get_results($wpdb->prepare(
        "SELECT v.id,p.display_name,v.church_name,v.square_num,v.visit_date,v.notes,v.submitted_at
         FROM {$wpdb->prefix}suvebingo_visits v
         JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=v.participant_id
         WHERE v.game_id=%d ORDER BY v.submitted_at DESC LIMIT 500",$gid)) : [];
    ?>
    <div class="wrap">
        <h1>EKB Külastused <?php echo $game?'('.esc_html($game->name).')':''; ?> (<?php echo count($rows); ?>)</h1>
        <table class="widefat striped">
            <thead><tr><th>#</th><th>Mängija</th><th>Kogudus</th><th>Ruut</th><th>Kuupäev</th><th>Märkused</th><th>Esitatud</th></tr></thead>
            <tbody>
            <?php foreach($rows as $r): ?>
            <tr>
                <td><?php echo esc_html($r->id); ?></td>
                <td><?php echo esc_html($r->display_name); ?></td>
                <td><?php echo esc_html($r->church_name); ?></td>
                <td><?php echo esc_html($r->square_num); ?></td>
                <td><?php echo esc_html($r->visit_date); ?></td>
                <td style="max-width:300px;font-style:italic;font-size:0.88em"><?php echo esc_html($r->notes); ?></td>
                <td><?php echo esc_html(substr($r->submitted_at,0,10)); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ── Church reports ─────────────────────────────────────────────
function suvebingo_admin_reports() {
    sb_cap(); global $wpdb;
    $game = suvebingo_get_active_game();
    $gid  = $game ? $game->id : 0;

    $selected_church = isset($_GET['church']) ? sanitize_text_field(wp_unslash($_GET['church'])) : '';

    // List of visited churches
    $visited = $gid ? $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT church_name FROM {$wpdb->prefix}suvebingo_visits WHERE game_id=%d ORDER BY church_name",$gid)) : [];

    ?>
    <div class="wrap">
        <h1>Koguduste aruanded <?php echo $game?'('.esc_html($game->name).')':''; ?></h1>

        <?php if(!$selected_church): ?>
        <p>Vali kogudus üksikasjaliku aruande vaatamiseks:</p>
        <table class="widefat striped" style="max-width:600px">
            <thead><tr><th>Kogudus</th><th>Külastusi</th><th>Vaatlusi</th><th></th></tr></thead>
            <tbody>
            <?php foreach($visited as $cn):
                $vc = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_visits WHERE game_id=%d AND church_name=%s",$gid,$cn));
                $oc = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_observations WHERE game_id=%d AND church_name=%s",$gid,$cn));
                ?>
            <tr>
                <td><?php echo esc_html($cn); ?></td>
                <td><?php echo esc_html($vc); ?></td>
                <td><?php echo esc_html($oc); ?></td>
                <td>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-reports&church='.urlencode($cn))); ?>" class="button button-small">Vaata aruannet</a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-export&type=church_pdf&church='.urlencode($cn))); ?>" class="button button-small">PDF</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php else:
            suvebingo_render_church_report( $selected_church, $gid, $game );
        endif; ?>
    </div>
    <?php
}

function suvebingo_render_church_report( $church, $gid, $game, $for_pdf = false ) {
    global $wpdb;

    // Church info from directory
    $info = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}suvebingo_churches WHERE name=%s LIMIT 1",$church));

    // Visits
    $visits = $wpdb->get_results($wpdb->prepare(
        "SELECT p.display_name,v.visit_date,v.notes
         FROM {$wpdb->prefix}suvebingo_visits v
         JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=v.participant_id
         WHERE v.game_id=%d AND v.church_name=%s ORDER BY v.visit_date ASC",$gid,$church));

    // Qualitative markers applied to this church
    $markers = $wpdb->get_results($wpdb->prepare(
        "SELECT square_label, COUNT(*) AS cnt
         FROM {$wpdb->prefix}suvebingo_observations
         WHERE game_id=%d AND church_name=%s
         GROUP BY square_label ORDER BY cnt DESC",$gid,$church));

    // Observation notes
    $obs_notes = $wpdb->get_results($wpdb->prepare(
        "SELECT p.display_name, o.square_label, o.visit_date, o.notes
         FROM {$wpdb->prefix}suvebingo_observations o
         JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=o.participant_id
         WHERE o.game_id=%d AND o.church_name=%s AND o.notes != '' ORDER BY o.visit_date",$gid,$church));

    if(!$for_pdf): ?>
    <p><a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-reports')); ?>">← Tagasi nimekirja</a>
    &nbsp;|&nbsp;
    <a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-export&type=church_pdf&church='.urlencode($church))); ?>" class="button button-primary">Ekspordi PDF</a>
    </p>
    <?php endif; ?>

    <h2><?php echo esc_html($church); ?></h2>
    <?php if($info): ?>
    <table class="form-table" style="max-width:600px">
        <?php if($info->region): ?><tr><th>Regioon</th><td><?php echo esc_html($info->region); ?></td></tr><?php endif; ?>
        <?php if($info->pastor): ?><tr><th>Pastor</th><td><?php echo esc_html($info->pastor); ?></td></tr><?php endif; ?>
        <?php if($info->address): ?><tr><th>Aadress</th><td><?php echo esc_html($info->address); ?></td></tr><?php endif; ?>
        <?php if($info->ekb_url && !$for_pdf): ?><tr><th>Leht</th><td><a href="<?php echo esc_url($info->ekb_url); ?>" target="_blank"><?php echo esc_html($info->ekb_url); ?></a></td></tr><?php endif; ?>
    </table>
    <?php endif; ?>

    <h3>Külastused (<?php echo count($visits); ?>)</h3>
    <?php if($visits): ?>
    <table class="widefat striped" style="max-width:700px">
        <thead><tr><th>Mängija</th><th>Kuupäev</th><th>Märkused</th></tr></thead>
        <tbody>
        <?php foreach($visits as $v): ?>
        <tr>
            <td><?php echo esc_html($v->display_name); ?></td>
            <td><?php echo esc_html($v->visit_date); ?></td>
            <td style="font-style:italic"><?php echo esc_html($v->notes); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: echo '<p>Külastusi pole.</p>'; endif; ?>

    <h3>Kvalitatiivne profiil — vaatlusmärgised</h3>
    <p style="color:#666;font-style:italic;font-size:0.9em">Mitu korda on eri külastajad selle koguduse kohta vastavat tunnust märkinud.</p>
    <?php if($markers): ?>
    <table class="widefat striped" style="max-width:600px">
        <thead><tr><th>Märgis</th><th>Kordade arv</th><th>Osakaal</th></tr></thead>
        <tbody>
        <?php
        $max = $markers[0]->cnt;
        foreach($markers as $m):
            $pct = $max > 0 ? round(($m->cnt/$max)*100) : 0;
        ?>
        <tr>
            <td><?php echo esc_html($m->square_label); ?></td>
            <td><?php echo esc_html($m->cnt); ?></td>
            <td>
                <div style="background:#eee;border-radius:3px;height:10px;width:200px;overflow:hidden;display:inline-block;vertical-align:middle">
                    <div style="width:<?php echo esc_attr($pct); ?>%;height:100%;background:#8b3a1a"></div>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: echo '<p>Vaatlusmärgiseid pole veel lisatud.</p>'; endif; ?>

    <?php if($obs_notes): ?>
    <h3>Vaatlusmärkused</h3>
    <table class="widefat striped" style="max-width:700px">
        <thead><tr><th>Mängija</th><th>Märgis</th><th>Kuupäev</th><th>Märkus</th></tr></thead>
        <tbody>
        <?php foreach($obs_notes as $o): ?>
        <tr>
            <td><?php echo esc_html($o->display_name); ?></td>
            <td style="font-size:0.85em"><?php echo esc_html($o->square_label); ?></td>
            <td><?php echo esc_html($o->visit_date); ?></td>
            <td style="font-style:italic"><?php echo esc_html($o->notes); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif;
}

// ── Testimonials ───────────────────────────────────────────────
function suvebingo_admin_testimonials() {
    sb_cap(); global $wpdb;
    if(isset($_POST['sb_add_testimonial'])) {
        sb_verify('testimonial');
        $q=$wpdb->insert("{$wpdb->prefix}suvebingo_testimonials",['quote'=>sanitize_textarea_field(wp_unslash($_POST['quote']??'')),'author'=>sanitize_text_field(wp_unslash($_POST['author']??'')),'active'=>1],['%s','%s','%d']);
        if($q) echo '<div class="notice notice-success"><p>Lisatud.</p></div>';
    }
    if(isset($_POST['sb_toggle_testimonial'])) {
        sb_verify('testimonial');
        $id=(int)($_POST['tid']??0);$cur=(int)($_POST['active']??0);
        if($id) $wpdb->update("{$wpdb->prefix}suvebingo_testimonials",['active'=>$cur?0:1],['id'=>$id],['%d'],['%d']);
    }
    if(isset($_POST['sb_delete_testimonial'])) {
        sb_verify('testimonial');
        $id=(int)($_POST['tid']??0);
        if($id && confirm_admin_referer('suvebingo_testimonial')) $wpdb->delete("{$wpdb->prefix}suvebingo_testimonials",['id'=>$id],['%d']);
    }
    $rows=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}suvebingo_testimonials ORDER BY sort_order,id");
    $n=sb_nonce('testimonial');
    ?>
    <div class="wrap"><h1>Tunnistused</h1>
    <form method="POST"><input type="hidden" name="_wpnonce" value="<?php echo esc_attr($n); ?>">
    <table class="form-table">
        <tr><th>Tsitaat</th><td><textarea name="quote" rows="3" class="large-text" required></textarea></td></tr>
        <tr><th>Autor</th><td><input name="author" type="text" class="regular-text" placeholder="Pastor Nimi, Kogudus" required></td></tr>
    </table>
    <p><button type="submit" name="sb_add_testimonial" class="button button-primary">Lisa</button></p>
    </form>
    <h2>Olemasolevad</h2>
    <table class="widefat striped">
        <thead><tr><th>Tsitaat</th><th>Autor</th><th>Aktiivne</th><th></th></tr></thead>
        <tbody><?php foreach($rows as $r): ?>
        <tr style="<?php echo $r->active?'':'opacity:0.5'; ?>">
            <td><?php echo esc_html(mb_substr($r->quote,0,100)).(mb_strlen($r->quote)>100?'…':''); ?></td>
            <td><?php echo esc_html($r->author); ?></td>
            <td><?php echo $r->active?'✅':'⏸'; ?></td>
            <td>
                <form method="POST" style="display:inline"><input type="hidden" name="_wpnonce" value="<?php echo esc_attr($n); ?>"><input type="hidden" name="tid" value="<?php echo esc_attr($r->id); ?>"><input type="hidden" name="active" value="<?php echo esc_attr($r->active); ?>"><button type="submit" name="sb_toggle_testimonial" class="button button-small"><?php echo $r->active?'Peata':'Aktiveeri'; ?></button></form>
                <form method="POST" style="display:inline" onsubmit="return confirm('Kustuta?')"><input type="hidden" name="_wpnonce" value="<?php echo esc_attr($n); ?>"><input type="hidden" name="tid" value="<?php echo esc_attr($r->id); ?>"><button type="submit" name="sb_delete_testimonial" class="button button-small button-link-delete">Kustuta</button></form>
            </td>
        </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php
}

// ── Export ─────────────────────────────────────────────────────
function suvebingo_admin_export() {
    sb_cap(); global $wpdb;
    $game = suvebingo_get_active_game();
    $gid  = $game ? $game->id : 0;

    // PDF export triggered via GET
    if ( isset($_GET['type']) && $_GET['type'] === 'church_pdf' && isset($_GET['church']) ) {
        if(!current_user_can('manage_options')) wp_die('Juurdepääs keelatud.');
        $church = sanitize_text_field(wp_unslash($_GET['church']));
        suvebingo_export_church_pdf($church, $gid, $game);
        exit;
    }

    // CSV export
    if(isset($_POST['sb_export'])) {
        sb_verify('export');
        $type = sanitize_text_field($_POST['export_type']??'visits');
        if($type==='visits') {
            $rows=$wpdb->get_results($wpdb->prepare(
                "SELECT p.display_name,p.mode,v.church_name,v.square_num,v.visit_date,v.notes,v.submitted_at
                 FROM {$wpdb->prefix}suvebingo_visits v
                 JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=v.participant_id
                 WHERE v.game_id=%d ORDER BY v.submitted_at DESC",$gid),ARRAY_A);
            $fn='suvebingo-kulastused-'.date('Y-m-d').'.csv';
            $hdrs=['Kuvanimi','Mäng','Kogudus','Ruut','Kuupäev','Märkused','Esitatud'];
        } elseif($type==='observations') {
            $rows=$wpdb->get_results($wpdb->prepare(
                "SELECT p.display_name,o.church_name,o.square_label,o.visit_date,o.notes,o.submitted_at
                 FROM {$wpdb->prefix}suvebingo_observations o
                 JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=o.participant_id
                 WHERE o.game_id=%d ORDER BY o.submitted_at DESC",$gid),ARRAY_A);
            $fn='suvebingo-vaatlused-'.date('Y-m-d').'.csv';
            $hdrs=['Kuvanimi','Kogudus','Märgis','Kuupäev','Märkused','Esitatud'];
        } else {
            $rows=$wpdb->get_results($wpdb->prepare(
                "SELECT display_name,name,email,home_church,mode,ekb_visits,obs_visits,ekb_bingos,registered_at
                 FROM {$wpdb->prefix}suvebingo_participants WHERE game_id=%d ORDER BY ekb_visits DESC",$gid),ARRAY_A);
            $fn='suvebingo-osalejad-'.date('Y-m-d').'.csv';
            $hdrs=['Kuvanimi','Nimi','E-post','Kodukogudus','Mäng','EKB külastused','Vaatlused','Bingo','Registreeritud'];
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename='.$fn);
        $out=fopen('php://output','w'); fprintf($out,chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($out,$hdrs);
        foreach($rows as $r) fputcsv($out,array_values($r));
        fclose($out); exit;
    }
    ?>
    <div class="wrap"><h1>Eksport</h1>
    <h2>Koguduse PDF aruanne</h2>
    <?php
    $visited=$gid?$wpdb->get_col($wpdb->prepare("SELECT DISTINCT church_name FROM {$wpdb->prefix}suvebingo_visits WHERE game_id=%d ORDER BY church_name",$gid)):[];
    ?>
    <table class="widefat striped" style="max-width:500px">
        <thead><tr><th>Kogudus</th><th></th></tr></thead>
        <tbody>
        <?php foreach($visited as $cn): ?>
        <tr><td><?php echo esc_html($cn); ?></td>
            <td><a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-export&type=church_pdf&church='.urlencode($cn))); ?>" class="button button-small button-primary">Laadi PDF</a></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <h2 style="margin-top:2rem">CSV eksport</h2>
    <form method="POST">
        <?php wp_nonce_field('suvebingo_export'); ?>
        <table class="form-table">
            <tr><th>Tüüp</th><td>
                <label><input type="radio" name="export_type" value="visits" checked> EKB külastused</label><br>
                <label><input type="radio" name="export_type" value="observations"> Vaatlusmärgised</label><br>
                <label><input type="radio" name="export_type" value="participants"> Osalejad</label>
            </td></tr>
        </table>
        <p><button type="submit" name="sb_export" class="button button-primary">Laadi CSV</button></p>
    </form>
    </div>
    <?php
}
