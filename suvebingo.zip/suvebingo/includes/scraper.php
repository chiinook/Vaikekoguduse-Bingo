<?php
/**
 * Suvebingo — Church directory scraper
 * Fetches kogudused.ee pages server-side (no CORS issues) and
 * extracts pastor, address, phone, email into the churches table.
 * Churches that cannot be scraped are flagged for manual entry.
 */
defined( 'ABSPATH' ) || exit;

// ── Admin submenu page ─────────────────────────────────────────
add_action( 'admin_menu', 'suvebingo_scraper_menu', 20 );
function suvebingo_scraper_menu() {
    add_submenu_page(
        'suvebingo',
        'Koguduste andmete uuendamine',
        'Skraper',
        'manage_options',
        'suvebingo-scraper',
        'suvebingo_scraper_page'
    );
}

// ── REST endpoint for AJAX scraping ───────────────────────────
add_action( 'rest_api_init', function() {
    register_rest_route( 'suvebingo/v1', '/scrape-church', [
        'methods'             => 'POST',
        'callback'            => 'suvebingo_scrape_one_church',
        'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        'args'                => [
            'church_id' => [ 'required' => true, 'type' => 'integer', 'minimum' => 1 ],
        ],
    ] );
} );

// ── Admin page ─────────────────────────────────────────────────
function suvebingo_scraper_page() {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Juurdepääs keelatud.' );
    global $wpdb;

    $churches = $wpdb->get_results(
        "SELECT id, name, region, ekb_url, pastor, address, phone, email, manual_entry
         FROM {$wpdb->prefix}suvebingo_churches
         WHERE in_ekb_pool = 1
         ORDER BY region, name"
    );

    $with_url    = array_filter( $churches, fn($c) => ! empty( $c->ekb_url ) );
    $without_url = array_filter( $churches, fn($c) => empty( $c->ekb_url ) );

    $nonce = wp_create_nonce( 'wp_rest' );
    $api   = esc_url_raw( rest_url( 'suvebingo/v1' ) );
    ?>
    <div class="wrap">
        <h1>Koguduste andmete uuendamine</h1>
        <p>
            See tööriist käib läbi kõik kogudused ja proovib <strong>kogudused.ee</strong>-lt
            automaatselt leida kontaktandmed (pastor, aadress, telefon, e-post).<br>
            Kogudused, mille lehte ei leita, saad käsitsi täita.
        </p>

        <div style="display:flex;gap:1.5rem;margin:1.5rem 0;flex-wrap:wrap">
            <div style="background:#fff;border:1px solid #ddd;padding:1rem 1.5rem;border-radius:4px;text-align:center">
                <strong style="font-size:1.8rem;color:#3a5c2e;display:block"><?php echo count($with_url); ?></strong>
                <span style="font-size:0.85rem;color:#666">kogudust URL-iga</span>
            </div>
            <div style="background:#fff;border:1px solid #ddd;padding:1rem 1.5rem;border-radius:4px;text-align:center">
                <strong style="font-size:1.8rem;color:#8b3a1a;display:block"><?php echo count($without_url); ?></strong>
                <span style="font-size:0.85rem;color:#666">ilma URL-ita (käsitsi)</span>
            </div>
        </div>

        <!-- Scrape controls -->
        <?php if ( $with_url ) : ?>
        <div style="background:#f0f6f0;border:1px solid #c3e6c3;padding:1rem 1.2rem;margin-bottom:1.5rem;border-radius:4px">
            <strong>Automaatne skrapeerimine</strong> —
            proovib kõigi <?php echo count($with_url); ?> koguduse lehelt andmeid tõmmata.
            Olemasolevaid käsitsi sisestatud andmeid <strong>ei kirjutata üle</strong>.<br><br>
            <button id="sb-scrape-all" class="button button-primary" onclick="SBScraper.runAll()">
                ▶ Skrapeeri kõik kogudused
            </button>
            <span id="sb-scrape-progress" style="margin-left:1rem;font-style:italic;color:#666"></span>
        </div>

        <div id="sb-scrape-results" style="margin-bottom:2rem"></div>
        <?php endif; ?>

        <!-- Churches with URLs (scrapeable) -->
        <h2>Kogudused kogudused.ee lehega (<?php echo count($with_url); ?>)</h2>
        <table class="widefat striped" id="sb-church-table">
            <thead><tr>
                <th>Nimi</th><th>Regioon</th><th>Pastor</th>
                <th>Aadress</th><th>Telefon</th><th>E-post</th>
                <th>Allikas</th><th>Toimingud</th>
            </tr></thead>
            <tbody>
            <?php foreach ( $with_url as $c ) : ?>
            <tr id="sb-row-<?php echo esc_attr($c->id); ?>">
                <td>
                    <strong><?php echo esc_html($c->name); ?></strong><br>
                    <a href="<?php echo esc_url($c->ekb_url); ?>" target="_blank" style="font-size:0.8em">kogudused.ee ↗</a>
                </td>
                <td><?php echo esc_html($c->region); ?></td>
                <td class="sb-field-pastor"><?php echo esc_html($c->pastor); ?></td>
                <td class="sb-field-address" style="font-size:0.88em"><?php echo esc_html($c->address); ?></td>
                <td class="sb-field-phone"><?php echo esc_html($c->phone); ?></td>
                <td class="sb-field-email" style="font-size:0.88em"><?php echo esc_html($c->email); ?></td>
                <td class="sb-field-source">
                    <?php if($c->manual_entry): ?>
                    <span style="color:#b8890a">✎ Käsitsi</span>
                    <?php else: ?>
                    <span style="color:#aaa">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <button class="button button-small"
                        onclick="SBScraper.scrapeOne(<?php echo esc_attr($c->id); ?>, this)">
                        ↻ Uuenda
                    </button>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-churches&edit='.$c->id)); ?>"
                        class="button button-small">✎ Muuda</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Churches without URLs (manual only) -->
        <?php if ( $without_url ) : ?>
        <h2 style="margin-top:2rem">Käsitsi sisestust vajavad kogudused (<?php echo count($without_url); ?>)</h2>
        <p style="color:#8b3a1a">
            Neil koguduskonnadel pole kogudused.ee lehte. Palun lisa nende andmed käsitsi.
        </p>
        <table class="widefat striped">
            <thead><tr><th>Nimi</th><th>Regioon</th><th>Pastor</th><th>URL</th><th>Toimingud</th></tr></thead>
            <tbody>
            <?php foreach ( $without_url as $c ) : ?>
            <tr>
                <td><strong><?php echo esc_html($c->name); ?></strong></td>
                <td><?php echo esc_html($c->region); ?></td>
                <td><?php echo esc_html($c->pastor); ?></td>
                <td>
                    <?php if($c->ekb_url): ?>
                        <a href="<?php echo esc_url($c->ekb_url); ?>" target="_blank"><?php echo esc_html($c->ekb_url); ?></a>
                    <?php else: ?>
                        <span style="color:#aaa;font-style:italic">Puudub</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=suvebingo-churches&edit='.$c->id)); ?>"
                        class="button button-primary button-small">✎ Lisa andmed</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <script>
    const SBScraper = {
        api:   '<?php echo esc_js($api); ?>',
        nonce: '<?php echo esc_js($nonce); ?>',

        async scrapeOne(churchId, btn) {
            if (btn) { btn.disabled = true; btn.textContent = '…'; }
            try {
                const res = await fetch(this.api + '/scrape-church', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': this.nonce,
                    },
                    body: JSON.stringify({ church_id: churchId }),
                });
                const data = await res.json();
                if (data.updated) {
                    this.updateRow(churchId, data);
                    if (btn) { btn.textContent = '✓'; btn.style.color = 'green'; }
                } else if (data.skipped) {
                    if (btn) { btn.textContent = '⏭ Käsitsi'; btn.disabled = false; }
                } else {
                    if (btn) { btn.textContent = '✗ Ei leitud'; btn.disabled = false; btn.style.color = '#8b3a1a'; }
                }
            } catch(e) {
                if (btn) { btn.textContent = '✗ Viga'; btn.disabled = false; }
            }
        },

        updateRow(churchId, data) {
            const row = document.getElementById('sb-row-' + churchId);
            if (!row) return;
            const set = (cls, val) => {
                const el = row.querySelector('.' + cls);
                if (el && val) el.textContent = val;
            };
            set('sb-field-pastor',  data.pastor);
            set('sb-field-address', data.address);
            set('sb-field-phone',   data.phone);
            set('sb-field-email',   data.email);
            const src = row.querySelector('.sb-field-source');
            if (src) src.innerHTML = '<span style="color:#3a5c2e">✓ Skrapeeritud</span>';
        },

        async runAll() {
            const btn = document.getElementById('sb-scrape-all');
            const progress = document.getElementById('sb-scrape-progress');
            const results  = document.getElementById('sb-scrape-results');
            const rows = document.querySelectorAll('[id^="sb-row-"]');

            btn.disabled = true;
            let done = 0, updated = 0, skipped = 0, failed = 0;
            results.innerHTML = '';

            for (const row of rows) {
                const churchId = parseInt(row.id.replace('sb-row-', ''));
                const nameEl   = row.querySelector('strong');
                const name     = nameEl ? nameEl.textContent : churchId;

                progress.textContent = `Skrapeerin: ${name} (${done + 1}/${rows.length})`;

                try {
                    const res = await fetch(this.api + '/scrape-church', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': this.nonce,
                        },
                        body: JSON.stringify({ church_id: churchId }),
                    });
                    const data = await res.json();
                    if (data.updated)      { this.updateRow(churchId, data); updated++; }
                    else if (data.skipped) { skipped++; }
                    else                   { failed++; }
                } catch(e) { failed++; }

                done++;
                // Small delay to avoid hammering the server
                await new Promise(r => setTimeout(r, 400));
            }

            progress.textContent = '';
            btn.disabled = false;

            results.innerHTML = `
                <div style="background:#fff;border:1px solid #ddd;padding:1rem 1.2rem;border-radius:4px">
                    <strong>Skrapeerimine lõpetatud</strong><br>
                    <span style="color:#3a5c2e">✓ Uuendatud: ${updated}</span> &nbsp;|&nbsp;
                    <span style="color:#b8890a">⏭ Käsitsi jäetud: ${skipped}</span> &nbsp;|&nbsp;
                    <span style="color:#8b3a1a">✗ Ei leitud: ${failed}</span>
                </div>`;
        }
    };
    </script>
    <?php
}

// ── Server-side scraper for one church ────────────────────────
function suvebingo_scrape_one_church( WP_REST_Request $req ) {
    global $wpdb;

    $church_id = (int) $req->get_param( 'church_id' );
    $church    = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}suvebingo_churches WHERE id = %d LIMIT 1",
        $church_id
    ) );

    if ( ! $church ) {
        return new WP_Error( 'not_found', 'Kogudust ei leitud.', [ 'status' => 404 ] );
    }

    // If manually entered, skip scraping — don't overwrite human data
    if ( $church->manual_entry && ( $church->pastor || $church->address ) ) {
        return rest_ensure_response( [ 'skipped' => true, 'reason' => 'manual_entry' ] );
    }

    if ( empty( $church->ekb_url ) ) {
        return rest_ensure_response( [ 'skipped' => true, 'reason' => 'no_url' ] );
    }

    // Fetch the page from the server (bypasses CORS)
    $response = wp_remote_get( $church->ekb_url, [
        'timeout'    => 10,
        'user-agent' => 'Mozilla/5.0 (compatible; SuvebingoBot/1.0; +https://edminsters.com)',
        'sslverify'  => true,
    ] );

    if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
        return rest_ensure_response( [ 'updated' => false, 'reason' => 'fetch_failed' ] );
    }

    $html = wp_remote_retrieve_body( $response );
    if ( empty( $html ) ) {
        return rest_ensure_response( [ 'updated' => false, 'reason' => 'empty_body' ] );
    }

    $extracted = suvebingo_parse_church_page( $html );

    if ( ! $extracted['found'] ) {
        return rest_ensure_response( [ 'updated' => false, 'reason' => 'no_data' ] );
    }

    // Only update fields that are currently empty (don't overwrite existing data)
    $updates = [];
    $formats = [];

    if ( ! empty( $extracted['pastor'] ) && empty( $church->pastor ) ) {
        $updates['pastor'] = sanitize_text_field( $extracted['pastor'] );
        $formats[] = '%s';
    }
    if ( ! empty( $extracted['address'] ) && empty( $church->address ) ) {
        $updates['address'] = sanitize_text_field( $extracted['address'] );
        $formats[] = '%s';
    }
    if ( ! empty( $extracted['phone'] ) && empty( $church->phone ) ) {
        $updates['phone'] = sanitize_text_field( $extracted['phone'] );
        $formats[] = '%s';
    }
    if ( ! empty( $extracted['email'] ) && empty( $church->email ) ) {
        $updates['email'] = sanitize_email( $extracted['email'] );
        $formats[] = '%s';
    }

    if ( $updates ) {
        $wpdb->update(
            $wpdb->prefix . 'suvebingo_churches',
            $updates,
            [ 'id' => $church_id ],
            $formats,
            [ '%d' ]
        );
        return rest_ensure_response( array_merge(
            [ 'updated' => true ],
            $updates
        ) );
    }

    return rest_ensure_response( [ 'updated' => false, 'reason' => 'nothing_new' ] );
}

// ── HTML parser ─────────────────────────────────────────────────
function suvebingo_parse_church_page( $html ) {
    $result = [
        'found'   => false,
        'pastor'  => '',
        'address' => '',
        'phone'   => '',
        'email'   => '',
    ];

    // kogudused.ee uses WordPress with specific field patterns.
    // We parse the rendered HTML for common patterns.

    // Strip scripts and styles to reduce noise
    $html = preg_replace( '/<script[^>]*>.*?<\/script>/si', '', $html );
    $html = preg_replace( '/<style[^>]*>.*?<\/style>/si',   '', $html );

    // ── Pastor / juhataja ──────────────────────────────────────
    // Pattern: label containing "pastor", "vanem", "juht", "juhataja"
    // followed by a name on the same or next line
    if ( preg_match(
        '/(?:pastor|vanem|juhataja|koguduse\s+juht)[:\s]*<[^>]+>([^<]{3,60})</i',
        $html, $m
    ) ) {
        $result['pastor'] = trim( strip_tags( $m[1] ) );
        $result['found']  = true;
    }
    // Fallback: look for <strong>Pastor</strong> Nimi pattern
    if ( empty( $result['pastor'] ) && preg_match(
        '/<strong[^>]*>(?:Pastor|Vanem|Juhataja)<\/strong>[:\s]*([A-ZÄÖÜÕ][a-zäöüõšž]+\s+[A-ZÄÖÜÕ][a-zäöüõšž]+)/u',
        $html, $m
    ) ) {
        $result['pastor'] = trim( $m[1] );
        $result['found']  = true;
    }

    // ── Address ───────────────────────────────────────────────
    // kogudused.ee often has address in a field labelled "Aadress" or in structured data
    if ( preg_match(
        '/(?:aadress|address)[:\s]*<[^>]+>([^<]{5,150})</i',
        $html, $m
    ) ) {
        $addr = trim( strip_tags( $m[1] ) );
        if ( strlen( $addr ) > 4 ) { $result['address'] = $addr; $result['found'] = true; }
    }
    // JSON-LD structured data address
    if ( empty( $result['address'] ) && preg_match(
        '/"streetAddress"\s*:\s*"([^"]{5,150})"/i',
        $html, $m
    ) ) {
        $result['address'] = trim( $m[1] );
        $result['found']   = true;
    }

    // ── Phone ─────────────────────────────────────────────────
    // Estonian phone numbers: +372 XXXX XXXX or 5XXX XXXX or 7XX XXXX
    if ( preg_match(
        '/(?:telefon|tel\.?|phone)[:\s]*[\S\s]{0,20}?(\+?372[\s\-]?[0-9\s\-]{7,15}|[5678][0-9]{6,7})/i',
        $html, $m
    ) ) {
        $phone = preg_replace( '/[^\d\+]/', '', $m[1] );
        if ( strlen( $phone ) >= 7 ) { $result['phone'] = $m[1]; $result['found'] = true; }
    }
    // Fallback: tel: links
    if ( empty( $result['phone'] ) && preg_match(
        '/href="tel:([^"]+)"/i',
        $html, $m
    ) ) {
        $result['phone'] = trim( $m[1] );
        $result['found'] = true;
    }

    // ── Email ─────────────────────────────────────────────────
    // mailto: links
    if ( preg_match(
        '/href="mailto:([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})"/i',
        $html, $m
    ) ) {
        $result['email'] = trim( $m[1] );
        $result['found'] = true;
    }
    // Plain email pattern in text
    if ( empty( $result['email'] ) && preg_match(
        '/\b([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})\b/',
        $html, $m
    ) ) {
        $email = $m[1];
        // Skip WordPress admin/noreply emails
        if ( ! preg_match( '/wordpress|noreply|example/i', $email ) ) {
            $result['email'] = $email;
            $result['found'] = true;
        }
    }

    return $result;
}
