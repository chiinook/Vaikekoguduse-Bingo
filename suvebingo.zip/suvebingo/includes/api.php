<?php
defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', 'suvebingo_register_routes' );

function suvebingo_register_routes() {
    $ns = 'suvebingo/v1';

    // Public
    register_rest_route( $ns, '/game',         [ 'methods' => 'GET',  'callback' => 'suvebingo_api_active_game',   'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/churches',     [ 'methods' => 'GET',  'callback' => 'suvebingo_api_churches',      'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/testimonials', [ 'methods' => 'GET',  'callback' => 'suvebingo_api_testimonials',  'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/leaderboard',  [ 'methods' => 'GET',  'callback' => 'suvebingo_api_leaderboard',   'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/top-cards',    [ 'methods' => 'GET',  'callback' => 'suvebingo_api_top_cards',     'permission_callback' => '__return_true' ] );

    // Auth required
    register_rest_route( $ns, '/register',  [ 'methods' => 'POST', 'callback' => 'suvebingo_api_register',  'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/resume',    [ 'methods' => 'POST', 'callback' => 'suvebingo_api_resume',    'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/card',      [ 'methods' => 'GET',  'callback' => 'suvebingo_api_get_card',  'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/card',      [ 'methods' => 'PUT',  'callback' => 'suvebingo_api_save_card', 'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/new-season','', [
        [ 'methods' => 'POST', 'callback' => 'suvebingo_api_new_season', 'permission_callback' => '__return_true' ],
    ] );
    register_rest_route( $ns, '/new-season', [ 'methods' => 'POST', 'callback' => 'suvebingo_api_new_season', 'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/visit',     [ 'methods' => 'POST', 'callback' => 'suvebingo_api_log_visit',    'permission_callback' => '__return_true' ] );
    register_rest_route( $ns, '/observe',   [ 'methods' => 'POST', 'callback' => 'suvebingo_api_log_observe',  'permission_callback' => '__return_true' ] );
}

// ── Security helpers ───────────────────────────────────────────
function suvebingo_rate_limit( $action, $limit = 60, $window = 3600 ) {
    $key  = 'suvebingo_rl_' . $action . '_' . md5( suvebingo_client_ip() );
    $hits = (int) get_transient( $key );
    if ( $hits >= $limit ) return false;
    set_transient( $key, $hits + 1, $window );
    return true;
}

function suvebingo_client_ip() {
    foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $k ) {
        if ( ! empty( $_SERVER[ $k ] ) ) {
            $ip = trim( explode( ',', $_SERVER[ $k ] )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
        }
    }
    return '0.0.0.0';
}

function suvebingo_auth( WP_REST_Request $req ) {
    $header = $req->get_header( 'authorization' );
    if ( ! $header || strpos( $header, 'Bearer ' ) !== 0 ) return null;
    $raw = trim( substr( $header, 7 ) );
    if ( strlen( $raw ) !== 64 || ! ctype_xdigit( $raw ) ) return null;
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}suvebingo_participants WHERE token_hash = %s LIMIT 1",
        hash( 'sha256', $raw )
    ) );
}

function suvebingo_token() {
    $raw = bin2hex( random_bytes( 32 ) );
    return [ $raw, hash( 'sha256', $raw ) ];
}

function suvebingo_valid_date( $d ) {
    if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) return false;
    $dt = DateTime::createFromFormat( 'Y-m-d', $d );
    return $dt && $dt->format( 'Y-m-d' ) === $d;
}

function suvebingo_valid_square( $sq ) {
    return (bool) preg_match( '/^[BINGO][1-5]$/i', $sq );
}

// ── Handlers ───────────────────────────────────────────────────

function suvebingo_api_active_game() {
    $game = suvebingo_get_active_game();
    if ( ! $game ) return new WP_Error( 'no_game', 'Aktiivset mängu ei leitud.', [ 'status' => 404 ] );
    return rest_ensure_response( [
        'id'         => (int) $game->id,
        'year'       => (int) $game->year,
        'name'       => $game->name,
        'start_date' => $game->start_date,
        'end_date'   => $game->end_date,
    ] );
}

function suvebingo_api_churches() {
    global $wpdb;
    $rows = $wpdb->get_results(
        "SELECT name, region, ekb_url, address, pastor, phone, in_ekb_pool
         FROM {$wpdb->prefix}suvebingo_churches
         ORDER BY region, name"
    );
    return rest_ensure_response( $rows );
}

function suvebingo_api_testimonials() {
    global $wpdb;
    return rest_ensure_response( $wpdb->get_results(
        "SELECT quote, author FROM {$wpdb->prefix}suvebingo_testimonials WHERE active=1 ORDER BY sort_order, id LIMIT 10"
    ) );
}

function suvebingo_api_register( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'register', 10, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju katseid.', [ 'status' => 429 ] );

    global $wpdb;
    $game = suvebingo_get_active_game();
    if ( ! $game ) return new WP_Error( 'no_game', 'Mäng pole aktiivne.', [ 'status' => 400 ] );

    $name         = sanitize_text_field( $req->get_param( 'name' ) );
    $display_name = sanitize_text_field( $req->get_param( 'display_name' ) );
    $email        = sanitize_email( $req->get_param( 'email' ) );
    $home_church  = sanitize_text_field( $req->get_param( 'home_church' ) );
    $mode         = in_array( $req->get_param( 'mode' ), [ 'ekb', 'obs' ], true ) ? $req->get_param( 'mode' ) : 'ekb';
    $partner      = sanitize_text_field( $req->get_param( 'partner' ) ?? '' );
    $card_json    = $req->get_param( 'card_json' );

    if ( empty( $name ) || strlen( $name ) > 120 )
        return new WP_Error( 'invalid', 'Nimi on nõutud.', [ 'status' => 400 ] );
    if ( ! is_email( $email ) )
        return new WP_Error( 'invalid', 'Kehtetu e-post.', [ 'status' => 400 ] );
    if ( empty( $home_church ) )
        return new WP_Error( 'invalid', 'Kodukogudus on nõutud.', [ 'status' => 400 ] );

    // Validate card JSON
    $card = json_decode( $card_json, true );
    if ( ! is_array( $card ) || count( $card ) !== 25 )
        return new WP_Error( 'invalid', 'Vigane kaardi formaat.', [ 'status' => 400 ] );

    // If display_name empty, build from name
    if ( empty( $display_name ) ) {
        $parts = explode( ' ', trim( $name ) );
        $display_name = count( $parts ) > 1
            ? $parts[0] . ' ' . mb_substr( end( $parts ), 0, 1 ) . '.'
            : $parts[0];
    }

    // Check existing in this game
    $existing = $wpdb->get_row( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}suvebingo_participants WHERE email=%s AND game_id=%d LIMIT 1",
        $email, $game->id
    ) );

    list( $raw, $hash ) = suvebingo_token();

    if ( $existing ) {
        $wpdb->update(
            $wpdb->prefix . 'suvebingo_participants',
            [ 'name'=>$name,'display_name'=>$display_name,'home_church'=>$home_church,'mode'=>$mode,
              'partner'=>$partner,'token_hash'=>$hash,'ekb_card_json'=>$card_json,
              'ekb_marked'=>json_encode([12]),'obs_marked'=>json_encode([]),'ekb_bingos'=>0,'ekb_visits'=>0,'obs_visits'=>0 ],
            [ 'id' => $existing->id ],
            [ '%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%d','%d' ], [ '%d' ]
        );
        return rest_ensure_response( [ 'token' => $raw, 'participant_id' => $existing->id ] );
    }

    $wpdb->insert(
        $wpdb->prefix . 'suvebingo_participants',
        [ 'game_id'=>$game->id,'name'=>$name,'display_name'=>$display_name,'email'=>$email,
          'home_church'=>$home_church,'mode'=>$mode,'partner'=>$partner,'token_hash'=>$hash,
          'ekb_card_json'=>$card_json,'ekb_marked'=>json_encode([12]),'obs_marked'=>json_encode([]) ],
        [ '%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ]
    );
    return rest_ensure_response( [ 'token' => $raw, 'participant_id' => $wpdb->insert_id ] );
}

function suvebingo_api_resume( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'resume', 5, 600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju katseid.', [ 'status' => 429 ] );

    global $wpdb;
    $email = sanitize_email( $req->get_param( 'email' ) );
    if ( ! is_email( $email ) ) return new WP_Error( 'invalid', 'Kehtetu e-post.', [ 'status' => 400 ] );

    $game = suvebingo_get_active_game();
    $p = $game ? $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}suvebingo_participants WHERE email=%s AND game_id=%d LIMIT 1",
        $email, $game->id
    ) ) : null;

    if ( $p ) {
        list( $raw, $hash ) = suvebingo_token();
        $wpdb->update( $wpdb->prefix . 'suvebingo_participants', [ 'token_hash' => $hash ], [ 'id' => $p->id ], [ '%s' ], [ '%d' ] );
        $resume_url = add_query_arg( 'suvebingo_resume', $raw, get_permalink( get_page_by_path('suvebingo') ) );
        wp_mail( $email, 'Suvebingo — jätka mängu',
            sprintf( "Tere %s,\n\nJätka mängu siit:\n%s\n\nLink kehtib 24 tundi.", esc_html( $p->name ), esc_url( $resume_url ) )
        );
    }
    return rest_ensure_response( [ 'sent' => true ] );
}

function suvebingo_api_get_card( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'card_get', 120, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju päringuid.', [ 'status' => 429 ] );
    $p = suvebingo_auth( $req );
    if ( ! $p ) return new WP_Error( 'unauthorized', 'Kehtetu sessioonimärk.', [ 'status' => 401 ] );
    return rest_ensure_response( [
        'name'         => $p->name,
        'display_name' => $p->display_name,
        'email'        => $p->email,
        'home_church'  => $p->home_church,
        'mode'         => $p->mode,
        'partner'      => $p->partner,
        'ekb_card_json'=> $p->ekb_card_json,
        'ekb_marked'   => $p->ekb_marked,
        'obs_marked'   => $p->obs_marked,
        'ekb_bingos'   => (int) $p->ekb_bingos,
        'ekb_visits'   => (int) $p->ekb_visits,
        'obs_visits'   => (int) $p->obs_visits,
        'game_id'      => (int) $p->game_id,
    ] );
}

function suvebingo_api_save_card( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'card_save', 120, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju päringuid.', [ 'status' => 429 ] );
    $p = suvebingo_auth( $req );
    if ( ! $p ) return new WP_Error( 'unauthorized', 'Kehtetu sessioonimärk.', [ 'status' => 401 ] );
    global $wpdb;

    $updates = [];
    $formats = [];

    if ( $req->get_param( 'ekb_marked' ) !== null ) {
        $m = json_decode( $req->get_param( 'ekb_marked' ), true );
        if ( is_array( $m ) ) { $updates['ekb_marked'] = json_encode( array_values( array_unique( array_filter( $m, 'is_int' ) ) ) ); $formats[] = '%s'; }
    }
    if ( $req->get_param( 'obs_marked' ) !== null ) {
        $m = json_decode( $req->get_param( 'obs_marked' ), true );
        if ( is_array( $m ) ) { $updates['obs_marked'] = json_encode( array_values( array_unique( array_filter( $m, 'is_int' ) ) ) ); $formats[] = '%s'; }
    }
    if ( $req->get_param( 'ekb_bingos' ) !== null ) { $updates['ekb_bingos'] = min( 12, max( 0, (int) $req->get_param( 'ekb_bingos' ) ) ); $formats[] = '%d'; }

    if ( $updates ) $wpdb->update( $wpdb->prefix . 'suvebingo_participants', $updates, [ 'id' => $p->id ], $formats, [ '%d' ] );
    return rest_ensure_response( [ 'saved' => true ] );
}

function suvebingo_api_new_season( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'new_season', 5, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju päringuid.', [ 'status' => 429 ] );
    $p = suvebingo_auth( $req );
    if ( ! $p ) return new WP_Error( 'unauthorized', 'Kehtetu sessioonimärk.', [ 'status' => 401 ] );

    global $wpdb;
    $game = suvebingo_get_active_game();
    if ( ! $game ) return new WP_Error( 'no_game', 'Mäng pole aktiivne.', [ 'status' => 400 ] );

    // Check already in this game
    $existing = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}suvebingo_participants WHERE email=%s AND game_id=%d LIMIT 1",
        $p->email, $game->id
    ) );
    if ( $existing ) return rest_ensure_response( [ 'already_registered' => true, 'token' => null ] );

    // Get prayer partner for new year
    $partner = $wpdb->get_var( $wpdb->prepare(
        "SELECT church_b FROM {$wpdb->prefix}suvebingo_partners WHERE game_id=%d AND church_a=%s LIMIT 1",
        $game->id, $p->home_church
    ) ) ?: '';

    $card_json = $req->get_param( 'card_json' );
    $card = json_decode( $card_json, true );
    if ( ! is_array( $card ) || count( $card ) !== 25 )
        return new WP_Error( 'invalid', 'Vigane kaardi formaat.', [ 'status' => 400 ] );

    list( $raw, $hash ) = suvebingo_token();
    $wpdb->insert(
        $wpdb->prefix . 'suvebingo_participants',
        [ 'game_id'=>$game->id,'name'=>$p->name,'display_name'=>$p->display_name,'email'=>$p->email,
          'home_church'=>$p->home_church,'mode'=>$p->mode,'partner'=>$partner,'token_hash'=>$hash,
          'ekb_card_json'=>$card_json,'ekb_marked'=>json_encode([12]),'obs_marked'=>json_encode([]) ],
        [ '%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ]
    );
    return rest_ensure_response( [ 'token' => $raw, 'participant_id' => $wpdb->insert_id, 'partner' => $partner ] );
}

function suvebingo_api_log_visit( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'visit', 30, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju päringuid.', [ 'status' => 429 ] );
    $p = suvebingo_auth( $req );
    if ( ! $p ) return new WP_Error( 'unauthorized', 'Kehtetu sessioonimärk.', [ 'status' => 401 ] );

    global $wpdb;
    $church     = sanitize_text_field( $req->get_param( 'church_name' ) );
    $square_num = strtoupper( sanitize_text_field( $req->get_param( 'square_num' ) ) );
    $date       = sanitize_text_field( $req->get_param( 'visit_date' ) );
    $notes      = substr( sanitize_textarea_field( $req->get_param( 'notes' ) ?? '' ), 0, 2000 );

    if ( empty( $church ) || strlen( $church ) > 200 ) return new WP_Error( 'invalid', 'Kehtetu koguduse nimi.', [ 'status' => 400 ] );
    if ( ! suvebingo_valid_square( $square_num ) ) return new WP_Error( 'invalid', 'Kehtetu ruudu number.', [ 'status' => 400 ] );
    if ( ! suvebingo_valid_date( $date ) ) return new WP_Error( 'invalid', 'Kehtetu kuupäev.', [ 'status' => 400 ] );

    // Prevent duplicate
    if ( $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}suvebingo_visits WHERE participant_id=%d AND square_num=%s LIMIT 1",
        $p->id, $square_num
    ) ) ) return new WP_Error( 'duplicate', 'Juba märgitud.', [ 'status' => 409 ] );

    $wpdb->insert(
        $wpdb->prefix . 'suvebingo_visits',
        [ 'participant_id'=>$p->id,'game_id'=>$p->game_id,'church_name'=>$church,'square_num'=>$square_num,'visit_date'=>$date,'notes'=>$notes ],
        [ '%d','%d','%s','%s','%s','%s' ]
    );
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->prefix}suvebingo_participants SET ekb_visits=ekb_visits+1, last_visit_at=%s WHERE id=%d",
        current_time('mysql'), $p->id
    ) );
    return rest_ensure_response( [ 'logged' => true ] );
}

function suvebingo_api_log_observe( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'observe', 60, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju päringuid.', [ 'status' => 429 ] );
    $p = suvebingo_auth( $req );
    if ( ! $p ) return new WP_Error( 'unauthorized', 'Kehtetu sessioonimärk.', [ 'status' => 401 ] );

    global $wpdb;
    $church  = sanitize_text_field( $req->get_param( 'church_name' ) );
    $sq_num  = strtoupper( sanitize_text_field( $req->get_param( 'square_num' ) ) );
    $sq_lbl  = sanitize_text_field( $req->get_param( 'square_label' ) );
    $date    = sanitize_text_field( $req->get_param( 'visit_date' ) );
    $notes   = substr( sanitize_textarea_field( $req->get_param( 'notes' ) ?? '' ), 0, 2000 );

    if ( empty( $church ) ) return new WP_Error( 'invalid', 'Kehtetu koguduse nimi.', [ 'status' => 400 ] );
    if ( ! suvebingo_valid_date( $date ) ) return new WP_Error( 'invalid', 'Kehtetu kuupäev.', [ 'status' => 400 ] );
    if ( strlen( $sq_lbl ) > 300 ) $sq_lbl = substr( $sq_lbl, 0, 300 );

    // Allow multiple observations per church (different squares)
    if ( $sq_num && $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}suvebingo_observations WHERE participant_id=%d AND church_name=%s AND square_num=%s LIMIT 1",
        $p->id, $church, $sq_num
    ) ) ) return new WP_Error( 'duplicate', 'Juba märgitud.', [ 'status' => 409 ] );

    $wpdb->insert(
        $wpdb->prefix . 'suvebingo_observations',
        [ 'participant_id'=>$p->id,'game_id'=>$p->game_id,'church_name'=>$church,'square_num'=>$sq_num,'square_label'=>$sq_lbl,'visit_date'=>$date,'notes'=>$notes ],
        [ '%d','%d','%s','%s','%s','%s','%s' ]
    );
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->prefix}suvebingo_participants SET obs_visits=obs_visits+1 WHERE id=%d", $p->id
    ) );
    return rest_ensure_response( [ 'logged' => true ] );
}

function suvebingo_api_leaderboard( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'leaderboard', 60, 3600 ) )
        return new WP_Error( 'rate_limit', 'Liiga palju päringuid.', [ 'status' => 429 ] );

    global $wpdb;
    $game = suvebingo_get_active_game();
    if ( ! $game ) return rest_ensure_response( [ 'players'=>[], 'stats'=>[], 'ekb_count'=>0, 'obs_count'=>0 ] );

    $mode = sanitize_text_field( $req->get_param( 'mode' ) ?: 'all' );
    $where = $mode !== 'all' ? $wpdb->prepare( 'AND mode=%s', $mode ) : '';

    $players = $wpdb->get_results( $wpdb->prepare(
        "SELECT display_name AS name, mode, ekb_visits, obs_visits, ekb_bingos, last_visit_at
         FROM {$wpdb->prefix}suvebingo_participants
         WHERE game_id=%d $where
         ORDER BY ekb_visits DESC, last_visit_at DESC LIMIT 10",
        $game->id
    ) );

    $stats = $wpdb->get_row( $wpdb->prepare(
        "SELECT COUNT(DISTINCT p.id) AS participants,
                SUM(p.ekb_visits) AS visits,
                COUNT(DISTINCT v.church_name) AS churches,
                SUM(CASE WHEN p.ekb_visits >= 24 THEN 1 ELSE 0 END) AS complete
         FROM {$wpdb->prefix}suvebingo_participants p
         LEFT JOIN {$wpdb->prefix}suvebingo_visits v ON v.participant_id=p.id
         WHERE p.game_id=%d $where",
        $game->id
    ) );

    $ekb_c = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_participants WHERE game_id=%d AND mode='ekb'", $game->id));
    $obs_c = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}suvebingo_participants WHERE game_id=%d AND mode='obs'", $game->id));

    return rest_ensure_response( [ 'players'=>$players, 'stats'=>$stats, 'ekb_count'=>$ekb_c, 'obs_count'=>$obs_c ] );
}

function suvebingo_api_top_cards( WP_REST_Request $req ) {
    if ( ! suvebingo_rate_limit( 'top_cards', 60, 3600 ) ) return new WP_Error( 'rate_limit', '', ['status'=>429]);
    global $wpdb;
    $game = suvebingo_get_active_game();
    if ( ! $game ) return rest_ensure_response( [ 'ekb'=>[], 'obs'=>[], 'recent'=>[] ] );

    $ekb = $wpdb->get_results( $wpdb->prepare(
        "SELECT church_name AS name, COUNT(*) AS visits
         FROM {$wpdb->prefix}suvebingo_visits WHERE game_id=%d
         GROUP BY church_name ORDER BY visits DESC, church_name ASC LIMIT 10", $game->id
    ) );
    $obs = $wpdb->get_results( $wpdb->prepare(
        "SELECT square_label AS name, COUNT(*) AS visits
         FROM {$wpdb->prefix}suvebingo_observations WHERE game_id=%d
         GROUP BY square_label ORDER BY visits DESC LIMIT 10", $game->id
    ) );
    $recent = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.display_name AS player, p.mode, v.church_name, '' AS square_label, v.visit_date, v.notes
         FROM {$wpdb->prefix}suvebingo_visits v
         JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=v.participant_id
         WHERE v.game_id=%d ORDER BY v.submitted_at DESC LIMIT 15", $game->id
    ) );

    return rest_ensure_response( [ 'ekb'=>$ekb, 'obs'=>$obs, 'recent'=>$recent ] );
}
