<?php
/**
 * PDF export for church reports.
 * Uses a pure-PHP HTML-to-PDF approach via output buffering + browser print
 * for shared hosting compatibility, with a fallback printable HTML page.
 * 
 * For production environments with Composer, swap the body of
 * suvebingo_export_church_pdf() with a Dompdf or TCPDF call.
 */
defined( 'ABSPATH' ) || exit;

function suvebingo_export_church_pdf( $church, $gid, $game ) {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Juurdepääs keelatud.' );

    global $wpdb;

    $info = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}suvebingo_churches WHERE name=%s LIMIT 1", $church
    ) );

    $visits = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.display_name, v.visit_date, v.notes
         FROM {$wpdb->prefix}suvebingo_visits v
         JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=v.participant_id
         WHERE v.game_id=%d AND v.church_name=%s ORDER BY v.visit_date ASC",
        $gid, $church
    ) );

    $markers = $wpdb->get_results( $wpdb->prepare(
        "SELECT square_label, COUNT(*) AS cnt
         FROM {$wpdb->prefix}suvebingo_observations
         WHERE game_id=%d AND church_name=%s
         GROUP BY square_label ORDER BY cnt DESC",
        $gid, $church
    ) );

    $obs_notes = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.display_name, o.square_label, o.visit_date, o.notes
         FROM {$wpdb->prefix}suvebingo_observations o
         JOIN {$wpdb->prefix}suvebingo_participants p ON p.id=o.participant_id
         WHERE o.game_id=%d AND o.church_name=%s AND o.notes != ''
         ORDER BY o.visit_date ASC",
        $gid, $church
    ) );

    $max_cnt = $markers ? (int) $markers[0]->cnt : 1;
    $game_name = $game ? esc_html( $game->name ) : '';
    $generated = date( 'd.m.Y' );

    // Output a printable HTML page styled for A4 print
    header( 'Content-Type: text/html; charset=utf-8' );

    echo '<!DOCTYPE html><html lang="et"><head><meta charset="UTF-8">';
    echo '<title>'.esc_html($church).' — Suvebingo aruanne</title>';
    echo '<style>
        @page { size: A4; margin: 2cm; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Georgia, serif; font-size: 11pt; color: #1a1510; line-height: 1.5; }
        .header { border-bottom: 3px solid #8b3a1a; padding-bottom: 0.8rem; margin-bottom: 1.5rem; }
        .header h1 { font-size: 20pt; color: #8b3a1a; margin-bottom: 0.2rem; }
        .header .meta { font-size: 9pt; color: #666; }
        .church-info { background: #f9f5ec; border: 1px solid #d4c090; padding: 0.7rem 1rem; margin-bottom: 1.5rem; font-size: 10pt; }
        .church-info table { width: 100%; border-collapse: collapse; }
        .church-info td { padding: 0.2rem 0.5rem; }
        .church-info td:first-child { font-weight: bold; width: 30%; color: #8b3a1a; }
        h2 { font-size: 13pt; color: #8b3a1a; border-bottom: 1px solid #d4c090; padding-bottom: 0.3rem; margin: 1.5rem 0 0.8rem; }
        h3 { font-size: 11pt; color: #3a5c2e; margin: 1.2rem 0 0.5rem; }
        table.data { width: 100%; border-collapse: collapse; font-size: 10pt; margin-bottom: 1rem; }
        table.data th { background: #8b3a1a; color: #fff; padding: 0.4rem 0.6rem; text-align: left; font-size: 9pt; }
        table.data td { padding: 0.35rem 0.6rem; border-bottom: 1px solid #e8d9b8; vertical-align: top; }
        table.data tr:nth-child(even) td { background: #fdf8ee; }
        .bar-wrap { display: flex; align-items: center; gap: 0.5rem; }
        .bar-bg { background: #e8d9b8; border-radius: 2px; height: 8px; flex: 1; overflow: hidden; }
        .bar-fg { height: 100%; background: #8b3a1a; border-radius: 2px; }
        .no-data { color: #999; font-style: italic; margin: 0.5rem 0; }
        .footer { margin-top: 2rem; padding-top: 0.5rem; border-top: 1px solid #d4c090; font-size: 9pt; color: #999; }
        .print-btn { position: fixed; top: 1rem; right: 1rem; background: #8b3a1a; color: #fff; border: none; padding: 0.5rem 1.2rem; border-radius: 3px; cursor: pointer; font-family: Georgia, serif; font-size: 10pt; }
        @media print { .print-btn { display: none; } }
    </style></head><body>';

    echo '<button class="print-btn" onclick="window.print()">Prindi / Salvesta PDF</button>';

    echo '<div class="header">';
    echo '<h1>'.esc_html($church).'</h1>';
    echo '<div class="meta">'.esc_html($game_name).' · Koostatud: '.esc_html($generated).' · EKB Liit Suvebingo</div>';
    echo '</div>';

    // Church info block
    if ( $info ) {
        echo '<div class="church-info"><table>';
        if ( $info->region )  echo '<tr><td>Regioon</td><td>'.esc_html($info->region).'</td></tr>';
        if ( $info->pastor )  echo '<tr><td>Pastor</td><td>'.esc_html($info->pastor).'</td></tr>';
        if ( $info->address ) echo '<tr><td>Aadress</td><td>'.esc_html($info->address).'</td></tr>';
        if ( $info->phone )   echo '<tr><td>Telefon</td><td>'.esc_html($info->phone).'</td></tr>';
        if ( $info->ekb_url ) echo '<tr><td>Veebileht</td><td>'.esc_html($info->ekb_url).'</td></tr>';
        echo '</table></div>';
    }

    // Visits
    echo '<h2>Külastused ('.count($visits).')</h2>';
    if ( $visits ) {
        echo '<table class="data"><thead><tr><th>Mängija</th><th>Kuupäev</th><th>Märkused</th></tr></thead><tbody>';
        foreach ( $visits as $v ) {
            echo '<tr><td>'.esc_html($v->display_name).'</td>';
            echo '<td>'.esc_html($v->visit_date).'</td>';
            echo '<td><em>'.esc_html($v->notes).'</em></td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="no-data">Külastusi pole.</p>';
    }

    // Qualitative profile
    echo '<h2>Kvalitatiivne profiil</h2>';
    echo '<p style="font-size:10pt;color:#666;margin-bottom:0.8rem;font-style:italic">Vaatlusmärgised — mitu korda on eri külastajad selle tunnuse märkinud.</p>';
    if ( $markers ) {
        echo '<table class="data"><thead><tr><th>Märgis</th><th>Kordade arv</th><th style="width:40%">Suhteline sagedus</th></tr></thead><tbody>';
        foreach ( $markers as $m ) {
            $pct = $max_cnt > 0 ? round( ($m->cnt / $max_cnt) * 100 ) : 0;
            echo '<tr><td>'.esc_html($m->square_label).'</td>';
            echo '<td>'.esc_html($m->cnt).'</td>';
            echo '<td><div class="bar-wrap"><div class="bar-bg"><div class="bar-fg" style="width:'.esc_attr($pct).'%"></div></div><span style="font-size:9pt">'.esc_html($pct).'%</span></div></td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="no-data">Vaatlusmärgiseid pole veel lisatud.</p>';
    }

    // Observation notes
    if ( $obs_notes ) {
        echo '<h2>Vaatlusmärkused</h2>';
        echo '<table class="data"><thead><tr><th>Mängija</th><th>Märgis</th><th>Kuupäev</th><th>Märkus</th></tr></thead><tbody>';
        foreach ( $obs_notes as $o ) {
            echo '<tr><td>'.esc_html($o->display_name).'</td>';
            echo '<td style="font-size:9pt">'.esc_html($o->square_label).'</td>';
            echo '<td>'.esc_html($o->visit_date).'</td>';
            echo '<td><em>'.esc_html($o->notes).'</em></td></tr>';
        }
        echo '</tbody></table>';
    }

    echo '<div class="footer">Suvebingo &copy; EKB Liit · '.esc_html($game_name).' · Konfidentsiaalne — ainult sisekasutuseks</div>';
    echo '</body></html>';
}
